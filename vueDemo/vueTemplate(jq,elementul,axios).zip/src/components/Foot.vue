<template>
	<div id="footnote" class="footer">
		<p><a href="javascript:;" target='_blank'>长园深瑞继保自动化有限公司</a> 版权所有 © 2005-2011 CYG SUNRI CO.,LTD. All Rights Reserved.</p>
	</div>
</template>
<script>
	import Vue from 'vue';
	import { Table,TableColumn} from 'element-ui';
	Vue.use(Table,TableColumn)
	export default{
		name:"FootNote",
		props:['alarmArr'],
		data(){
			return {
				// alarmData:[]
			}
		},
		components:{			
			'el-table':Table,
			'el-table-column':TableColumn,			
		},
		methods:{

		},
		mounted(){
			this.$nextTick(() => {				
				var windowH = window.innerHeight || document.documentElement.clientHeight;//可视窗口高度
				var bodyH = document.body.scrollHeight || document.documentElement.scrollHeight;//全文高度
				// console.log(123,windowH,bodyH)
				if(windowH > bodyH){
					$("#footnote").addClass('fixed')
				};
			});			
			$(function(){
				/*var windowH = window.innerHeight || document.documentElement.clientHeight;//可视窗口高度
				var bodyH = document.body.scrollHeight || document.documentElement.scrollHeight;//全文高度
				console.log(windowH,bodyH)
				if(windowH > bodyH){
					$("#footnote").addClass('fixed')
				};*/
			});
		}
	}
</script>
<style scoped>
	#footnote{
		width: 100%;
		height: 40px;
		background: #fefefe;
		/* position: fixed;
		bottom: 0; */
		line-height: 40px;
		margin-top: 10px;
	}	
	.fixed{
		position: fixed;
		bottom: 0;
	}	
	a{color: #208C7D;}	
</style>