<template>
	<div class="err">
		<home-header></home-header>
		<div class="main">
			<p><img src="../assets/error.png" alt=""></p>
		</div>
		<foot-note></foot-note>
	</div>
</template>
<script>
	import Vue from 'vue';
	import HomeHeader from './HomeHeader'
	import FootNote from './Foot'
	export default {
		name:'error',
		data(){
			return {

			}
		},
		components:{
			HomeHeader,	
			FootNote,	
		},
		mounted(){
			this.$bus.$emit('activeIndex','0');	
		}
	}
</script>
<style scoped>
	.main p{
		position: fixed;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
		margin: auto;
		height: 240px;
	}
	.err #footnote{
		position: fixed;
		bottom: 0;
	}
</style>