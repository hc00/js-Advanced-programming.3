<template>
	<div>
		<router-link to="/bimviz">三维监测</router-link>
		<router-link to="/home">home</router-link>
		<router-link to="/foo1">foo1</router-link>
		<router-link to="/">App</router-link>

		<div class="tree">
			<el-tree
			  	:props="props"  :load="loadNode" node-key='id' highlight-current  lazy  show-checkbox ref='loadTree' @current-change="handleCurrentChange">
			</el-tree>
		</div>
		<div class="tree">
			<el-tree
		  		:props="props1"  :load="loadNode1"  lazy  show-checkbox ref='loadTree1' @node-click="handleNodeClick" @node-contextmenu="handleNodeContextmenu" @check="handleCheck" @check-change="handleCheckChange" @current-change="handleCurrentChange">
			</el-tree>
		</div>
		<input type="text" v-model='msg'>
		<div id="view"></div>
		<div id="messages"></div>
	</div>
</template>
<script>
	import Vue from 'vue'
	import {Tree,Input,Tabs,TabPane,Card,} from 'element-ui'
	Vue.use(Tree,Input,Tabs,TabPane,Card,)
	export default{
		name:'bimviz',
		data(){
			return {
				bimviz:null,
				msg:'asd',
				svgId:'',
				m_selectElementID:'',

				props: {
          				label: 'name',
          				children: 'zones'
        			},
        			count: 1,

				props1: {
          				label: 'name',
          				children: 'zones',
          				isLeaf: 'leaf'
        			},
			}
		},
		components:{
			'el-input':Input,
			'el-tabs':Tabs,
			'el-tab-pane':TabPane,
		},
		methods:{
			loadNode(node, resolve) {
        			if (node.level === 0) {
          				return resolve([{ name: 'region',id:0 }]);
        			};
        			if (node.level > 1) return resolve([]);

        			setTimeout(() => {
          				const data = [{
            				name: 'leaf',
            				id:1,
            				leaf: true
          				}, {
            				name: 'zone',
            				id:2
          				}];
          				resolve(data);
        			}, 500);
      		},
      		loadNode1(node, resolve) {
        			if (node.level === 0) {
          				return resolve([{ name: 'region1' }, { name: 'region2' }]);
        			};
        			if (node.level > 3) return resolve([]);

        			var hasChild;
        			if (node.data.name === 'region1') {
          				hasChild = true;
        			} else if (node.data.name === 'region2') {
          				hasChild = false;
        			} else {
          				hasChild = Math.random() > 0.5;
        			};

        			setTimeout(() => {
          				var data;
          				if (hasChild) {
            				data = [{
              					name: 'zone' + this.count++
            				}, {
              					name: 'zone' + this.count++
            				}];
          				} else {
            				data = [];
          				};
          				resolve(data);
        			}, 500);
      		},
      		handleCheck(	data,checked){
      			console.log(data,checked,'check')
      		},
			handleCheckChange(data, checked, indeterminate) {
        			console.log(data, checked, indeterminate,'check-change');
      		},
      		handleCurrentChange(data,node){
      			console.log(data,node,'current-change')
      		},
      		handleNodeClick(data) {
        			console.log(data,'node-click');
      		},  
      		handleNodeContextmenu(e,data,node,ele){
      			console.log(e,data,node,ele,'node-contextmenu');
      		}
		},		
		mounted(){	window.$vm = this;
			var projId = "";
          		projId = "03448e0a-a278-4333-8195-b12941836394";
          		// projId = "a71b2fdc-0be1-4769-81a1-03b056be001b";

			/*this.bimviz = new BIMVIZ.RenderEngine({
            		projectId: projId,
            		renderDomId: 'view',
            		ip: "cloud.bimviz.io",
            		port: 10001, 
            		key: 'bb1c032f-9247-4c45-9f5b-3d436cda0950', 
            		// ip: "10.1.102.163",
            		// port: '7005', 
            		// key: 'B3056CC9-13DB-4fcc-9FC3-6604D93304F4',
            		// resizeMode: 'fullpage',
				resourcePath:'../../static',
				logo:false,//无LOGO
				
        		});
			var msgControl = new BIMVIZ.UI.DefaultMessageControl(this.bimviz, 'messages');
			this.bimviz.start();			
			this.bimviz.addListener(BIMVIZ.EVENT.OnLoadingResult,function(evt){
                    	//场景加载结束
                    	console.log('OnLoadingResult',Date.now());
            	});
			this.bimviz.addListener(BIMVIZ.EVENT.OnSceneLoadCompleted,function(evt){
                    	//场景数据分块加载完毕（既场景全部加载完毕）
                    	console.log('OnSceneLoadCompleted',Date.now());
            	});
          		this.bimviz.addListener(BIMVIZ.EVENT.OnLoadProgressStep,function(evt){
          			//网络数据加载进度更新
				console.log(evt,evt.args.total ,evt.args.current )
			});
			// this.bimviz.addListener(BIMVIZ.EVENT.OnShowDebugInfo,function(evt){
			// 	console.log(evt)
			// });
			this.bimviz.addListener(BIMVIZ.EVENT.ErrorMessage,function(evt){
				console.log(evt)
			});
			this.bimviz.addListener(BIMVIZ.EVENT.OnServerDisconnected,function(evt){
				//失去服务器连接（例如：断网）
				console.log(evt);
				$('#messages').html('');
			});
			this.bimviz.addListener(BIMVIZ.EVENT.OnPickElement,function (evt) {	console.log("选中",evt)
				//标签坐标
				//m_markerPoint = evt.args.point.clone().sub(m_bimEngine.CenterPosition);	
				this.m_selectElementID = evt.args.elementId;	
				console.log(this.m_selectElementID)
			});*/
		},
		beforeRouteEnter (to, from, next) {
			console.log(from)
  			next(vm => {
    				// 通过 `vm` 访问组件实例
    				console.log(vm,53)
    				/*if(from.name == 'home'){		console.log(vm.$route)
    					if(vm.$route.params.svgId !== undefined){
    						vm.svgId = vm.$route.params.svgId;
						let highlightManager	= 	vm.bimviz.getHighlightManager();
	      				highlightManager.clearHighlightElementList();
	      				highlightManager.highlightElement(vm.svgId);
    					};    					
    				}*/
  			})
		},
		beforeRouteLeave (to, from, next) {			console.log(+new Date(),to)
    			// 导航离开该组件的对应路由时调用
    			// 可以访问组件实例 `this`
    			if(this.bimviz){
    				this.bimviz.dispose();						
				this.bimviz = null;
				window.$vm = null;
			}    			
    			next();
  		},
		activated: function () {
      		console.log('bimviz activated',this)

      		if(this.$route.params.svgId !== undefined){
				/*this.svgId = this.$route.params.svgId;
				let highlightManager	= 	this.bimviz.getHighlightManager();
      			highlightManager.clearHighlightElementList();
      			highlightManager.highlightElement(this.svgId);*/
      		}
    		},
    		deactivated: function () {
      		console.log('bimviz deactivated')
    		}
	}
</script>
<style scoped>
	#view{
		width: 500px;
		height: 500px;
		margin: 0 auto;
	}
	.tree{
		width: 50%;margin: 10px auto;
		height: 500px;
		overflow-x: scroll;
		overflow-y: auto;		
		border: 2px solid #cbcbcb;
	}
	.el-tree-node__content:hover{
		background-color: #d9e7fb;
	}
	.el-tree>.el-tree-node{
		min-width: 100%;
		display: inline-block !important;
	}
</style>