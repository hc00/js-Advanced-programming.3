<template>
	<div class="wrapper">
		<home-header></home-header>
		<div class="hisalarm">
			<div class="condition clearfix">
				<!-- <div class="chooseDate">
					<el-date-picker
					@change='timeChange'				
					  v-model="timeValue"
					  type="datetimerange"
					  :picker-options="pickerOptions"
					  range-separator="至"
					  start-placeholder="开始日期"
					  end-placeholder="结束日期"
					  align="right">
					</el-date-picker>			
				</div> -->
				<div class="startTime left">
					<el-date-picker  v-model="startTime" type="date"  placeholder="开始日期"   :picker-options="pickerOptions0" value-format="timestamp" >					
					</el-date-picker>
				</div>
				<div class="endTime left">
					<el-date-picker  v-model="endTime" type="date"  placeholder="结束日期"   :picker-options="pickerOptions1" value-format="timestamp">
					</el-date-picker>
				</div>
				<div class="device left">
				  	<el-select v-model="deviceValue" placeholder="请选择设备" clearable>
				    		<el-option v-for="item in deviceData" :key="item.value" :label="item.label" :value="item.value">
				    		</el-option>
				  	</el-select>
				</div>
				<div class="level left">
					<el-select v-model="levelValue" placeholder="请选择等级" clearable>
				    		<el-option v-for="item in levelData" :key="item.value" :label="item.label" :value="item.value">
				    		</el-option>
				  	</el-select>
				</div>	
				<el-button  style='margin-top: 14px;' type="primary" size="small" icon="document" @click="getAlarm(pageSize,1,startTime,endTime,deviceValue,levelValue)" :loading="sendLoading" >查询</el-button>			
			</div>			
			
			<div class="alarmtable">
				<el-table    :data="alarmData" :row-class-name="tableRowClassName"  border style="" max-height='750' height='750' style="width:90%;margin:0 auto">
					<!-- <el-table-column label="历史告警"> -->
					<el-table-column :label="title">					
						<el-table-column      prop="Time"      label="时间" align="center">    </el-table-column>
						<el-table-column      prop="deviceId"      label="设备" align="center">    </el-table-column>
						<el-table-column      prop="level"      label="等级" align="center">    </el-table-column>
						<el-table-column      prop="Name"    label="名称"  align="center" >    </el-table-column>
						<el-table-column           label="状态" align="center">
							<template slot-scope="scope"><div class="cell"> {{ scope.row.State == 1?'动作':'复归' }}</div></template>    
						</el-table-column>
						<el-table-column           label="系统" align="center">
							<template slot-scope="scope"><div class="cell"> {{ scope.row.system == 1?'主控':'辅控' }}</div></template>    
						</el-table-column>
					</el-table-column>			    			
				</el-table>
			</div>
			<div class="pagination">	  			
				<el-pagination background
					@size-change="handleSizeChange"
					@current-change="handleCurrentChange"
					@prev-click="handlePrevClick"
					@next-click="handleNextClick"
					:current-page.sync="currentPage"
					:page-sizes="pageSizes"
					:page-size="pageSize"
					layout="total, sizes, prev, pager, next, jumper"
					:total="totalPage">
				</el-pagination>
			</div>
		</div>
		<foot-note></foot-note>
	</div>
</template>
<script>
	import Vue from 'vue'
	import HomeHeader from './HomeHeader'
	import FootNote from './Foot'
	import { Table,TableColumn,Pagination,TimePicker,TimeSelect,DatePicker,Select,Option,Loading,Button} from 'element-ui';
	Vue.use(Table,TableColumn,Pagination,TimePicker,TimeSelect,DatePicker,Select,Option,Loading,Button)


	export default {
		name:'AlarmMessage',
		props:[],
		data(){
			return {title:'历史告警',
				alarmData:[],						//历史告警数据
				currentPage: 1,					//当前页数
				totalPage:0,						//数据总条数
				pageSize:30,						//每页数据的条数
				pageSizes:[30,50,100],			//选择每页的条数
				sendLoading:false,				//查询数据按钮loading				
				//开始时间配置项
				pickerOptions0: {
                		disabledDate: (time) => {
                			var yearsBefore = Date.now() - 5*365*24*60*60*1000;	//console.log(new Date(yearsBefore),'start')
                    			if (this.endTime != null) {
                        			return time.getTime() > Date.now() || time.getTime() >= this.endTime;
                    			} else {
                        			return time.getTime() > Date.now() || time.getTime() < yearsBefore;
                    			}
                		}
            		},
            		//结束时间配置项
		   		pickerOptions1: {
		                disabledDate: (time) => {
		                	var yearsBefore = Date.now() - 5*365*24*60*60*1000;	//console.log(new Date(yearsBefore))
		                    return time.getTime() <= this.startTime || time.getTime() > Date.now() || time.getTime() < yearsBefore;
		    			}
		    		},		        
		        	deviceData:[],				//截取的30条告警间隔
		        	deviceLists:[],				//告警间隔数据
		        	levelData:[{
		        		value:null,
		        		label:'所有等级'
		        	},{
		        		value:'1',
		        		label:'1'
		        	},{
		        		value:'2',
		        		label:'2'
		        	},{
		        		value:'3',
		        		label:'3'
		        	},{
		        		value:'4',
		        		label:'4'
		        	},{
		        		value:'5',
		        		label:'5'
		        	}],
		        	systemData:[{
		        		value:"All",
		        		label:'全部系统'
		        	},{
		        		value:"1",
		        		label:"主控"
		        	},{
		        		value:"2",
		        		label:'辅控'
		        	}],
		        	startTime:null,
		        	endTime:null,
		        	levelValue:null,				//选择的等级		        	
		        	deviceValue:null			//选择的间隔
		        	//timeValue:'',		//选取的起止时间 	["开始时间","结束时间"]
		        	//systemType:'All'		//主控/辅控
			}
		},
		components:{
			HomeHeader,
			FootNote,
			'el-date-picker':DatePicker,
			'el-table':Table,
			'el-table-column':TableColumn,
			'el-pagination':Pagination,
			'el-select':Select,
			'el-option':Option,
			'el-button':Button,
		},
		methods:{
			/*获取历史报警信息
			*pagesize:每页的条数，page:选择的页数
			*start,end 起止时间
			*interval:间隔
			*level:等级
			*/
			getAlarm(pagesize,page,startTime,endTime,device,level){		//console.log(device!= '',device)
				var _this = this;
				this.sendLoading = true;
				if(!startTime || !endTime || device== '' || level== '' ){	
					this.MessageBox.alert('请选择完成后再次查询', '提示', {
						confirmButtonText: '确定',
			          		callback: action => {
			            		this.sendLoading = false;
			          		},
			          		center:true
			        	});
					return false;
				};					
				console.time("计时器-all");
				let loadingInstance  = null;
				var myInterceptor = this.axios.interceptors.request.use(function (config) {//console.log(config)
			    		// 在发送请求之前做些什么
			    		loadingInstance = Loading.service({
			    			// fullscreen:false,
			    			target:'.alarm',
			    			text:'拼命加载中...',
			    			background:'rgba(0,0,0,.8)'
			    		});
			    		return config;
			  	}, function (error) {
			    		// 对请求错误做些什么
			    		return Promise.reject(error);
			  	});console.time("计时器一axios");
			  	var config = {
					onDownloadProgress: progressEvent => {console.log(progressEvent)
  						// var complete = (progressEvent.loaded / progressEvent.total * 100 | 0) + '%'
  						// this.progress = complete
					},        						
				};
				this.axios.post(`${this.dataApi}/hisalarm`,{
					start:startTime,
					end:endTime,
					deviceId:device,
					level:level,					
				},config).then(function(data){
					console.log(data.data,data);console.timeEnd("计时器一axios");
					
					if($.isEmptyObject(data.data)){	//如果数据为空
						// alert("没有历史报警信息")
						_this.MessageBox.alert('没有历史报警信息', '提示', {
					          		confirmButtonText: '确定',
					          		callback: action => {
					            		
					          		},
					          		center:true
					        	});
					}else{					//有则遍历处理数据
						var arr = [],Data = data.data;
						console.time('计时器3-for')
						for(var i = 0; i < Data.length; i++){	
							var singnalName = Data[i]['v3dYx']['signalName'];		//信号名称
							var state = Data[i]['state'];								//状态值
							//var time = new Date(Data[i]['date']).format("yyyy-MM-dd hh:mm:ss");	//时间
							var time = new Date(Data[i]['date']).format();			//时间
							var bayName = Data[i]['v3dYx']['deviceId']	;			//设备
							var level = Data[i]['v3dYx']['level']	;						//等级
							var systemType = Data[i]['v3dYx']['systemType'];		//系统
							//遍历匹配间隔名称
							for(var key in _this.deviceLists){
								if(bayName == key){
									bayName = _this.deviceLists[key];
								}
							};							 
													
							switch(level){
								case 1:
									level = '事故';
									break;
								case 2:
									level = '异常';
									break;
								case 3:
									level = '越限';
									break;		
								case 4:
									level = '变位';
									break;	
								case 5:
									level = '告知';
									break;	
							};							
							arr.push({
								Name:singnalName,
								State:state,
								Time:time,
								deviceId:bayName,
								level:level,
								system:systemType
							});							
						};console.timeEnd('计时器3-for')								
						_this.totalPage = arr.length;		//绑定总条数
						pagesize = Number(pagesize);
						page = Number(page);
						if(arr.length > pagesize){		//如果总条数大于1页
							var data = arr.slice(pagesize*(page-1),pagesize*page);	//根据页数截取数据
							_this.alarmData = data;
						}else{
							_this.alarmData = arr;
						};
						//请求成功后关闭loading
						loadingInstance.close();
						_this.axios.interceptors.request.eject(myInterceptor);	
						_this.sendLoading = false;												
					}console.timeEnd("计时器-all");
				}).catch(function(err){
					console.log(err);
					//请求成功后关闭loading
					loadingInstance.close();
					_this.axios.interceptors.request.eject(myInterceptor);
					_this.sendLoading = false;						
					_this.Message({
            					type: 'info',
            					center:true,
            					message: '未能成功获取数据'
          					});
				});
				// };				
			},			
			//改变每页条数
			handleSizeChange(val) {
				console.log(`每页 ${val} 条`,val);
				this.pageSize = val;
				//判断选择时间
				if(this.timeValue === null || this.timeValue === ""){
					return false
				};
				this.getAlarm(val,this.currentPage,this.timeValue[0],this.timeValue[1],this.deviceValue,this.levelValue);
				/*Vue.nextTick(function () {
					// DOM 更新了
					this.axios.then(function(res){
						this.totalPage = res.data.Data.Total;
					});
				})*/
			},
			//改变页数
			handleCurrentChange(val) {
				console.log(`当前页: ${val}`,'pagesize  change',val);
				//判断选择时间
				if(this.timeValue === null || this.timeValue === ""){
					return false
				};								
				this.getAlarm(this.pageSize,val,this.timeValue[0],this.timeValue[1],this.deviceValue,this.levelValue);
			},
			handlePrevClick(val){

			},
			handleNextClick(val){

			},				
			//获取警报设备
			getDevice(){
				let _this = this;
				this.axios.get(`${this.dataApi}/device`).then(function(data){
					console.log(data)
					var data = data.data,arr = [{value:null,label:'所有设备'}];
					_this.deviceLists = data;
					for(var key in data){						
						arr.push({
							value:key,
							label:data[key]
						});
						if(arr.length === 30){
							break;
						}
					};					
					_this.deviceData = arr;
				}).catch(function(err){
					console.log(err)
				})
			},
			tableRowClassName({row, rowIndex}) {//console.log(row,rowIndex)
      				/*if (rowIndex === 1) {
        					return 'warning-row';
      				} else if (rowIndex === 3) {
        					return 'success-row';
      				}
      				return '';*/        				
    				switch(row['level']){
    					case '事故':
						return 'danger-row';
						break;
					case '异常':
						return 'warning-row';
						break;						
					case '变位':
						return 'primary-row';
						break;	
					case '告知':
						return 'primary-row';
						break;	
					case'越限':
						return 'outLimit-row';
					default:
						return '';
      			};
    			},	
		},		
		watch:{			
					
		},
		mounted(){	window.$vm = this;
			this.$bus.$emit('activeIndex','4');
			this.getDevice();	
		},
		beforeDestroy(){
			window.$vm = null;
		}
	}
</script>
<style scoped>
	
	.alarm{
		/* width: 1000px; */
		margin: 0 auto;
		padding: 10px 30px;
	}
	.condition{
		width: 660px;
		margin: 0 auto;
	}	
	.startTime .el-date-editor,.endTime .el-date-editor{		
		width: 150px;
		margin: 10px 0;
	}
	.endTime .el-date-editor{
		margin: 10px 5px;
	}
	.device{
		width: 120px;
		margin: 10px 5px;
	}
	.level{
		width: 120px;
		margin: 10px 5px;
	}
	.system{
		width: 120px;margin: 10px 0;
	}	
	
</style>
<style>
	.el-table__empty-block{
		height: 654px !important;
	}
	.pagination{
		margin: 10px auto;
		width: 100%;		
	}
	.el-pagination.is-background .el-pager li:not(.disabled).active{
		background-color: #208C7D;
	}
	.el-table .warning-row{
		background-color: #e6a23c;		
	}
	.el-table .danger-row{
		background-color: #f56c6c;
	}
	.el-table .primary-row{
		background-color: #409eff;			
	}
	.el-table .outLimit-row{
		background: #FFEB3B;
		/* background: #9E9E9E; */
	}
</style>