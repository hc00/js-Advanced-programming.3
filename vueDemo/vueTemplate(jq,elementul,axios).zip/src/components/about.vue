<template>
	<div id="about">
		<home-header></home-header>
		<div class="aboutUs box">
			<h4 class="title">公司简介</h4>
			<p ><strong>长园深瑞继保自动化有限公司</strong>（原深圳南瑞科技有限公司）是专业的电力系统自动化和智能化知名品牌，致力于全球能源技术创新与优质服务。1994年由中国电力部· 电力自动化研究所 · 元件保护与变电站综合自动化研究室改制成立。业务覆盖全球60多个国家，是国家电网、南方电网及各大能源公司主要合作伙伴。</p>

			<p style="margin-bottom:5px;"><strong>专注科研，以尖端技术和精湛工艺，保持产品及解决方案的先进性和完整性。</strong></p>
			<p>长园深瑞通过不断技术创新，形成了一系列拥有自主知识产权和历经时间检验的电力系统自动化技术体系，电网保护控制与自动化技术成功应用于全球15000余座变电站，首创的就地化保护技术引领智能电网革新发展；60000余台配网自动化产品应用全国，一二次融合技术提升配电设备运行水平、运维质量与效率，服务配电网智能化发展；多次参与电动汽车充电设施行业标准制定，在国家电网、南方电网等高端客户市场中标份额领先；新能源领域技术与集成服务快速发展，累计服务装机容量超50GW；智能化工具系列产品大大提升技术可靠性及工作效率；智能一次设备系列产品凭借控制和保护技术优势赢得了客户高度认可。</p>
			
			<p style="margin-bottom:5px;"><strong>成绩斐然，在电力行业标杆项目和国家重点工程中,长园深瑞从未缺席。</strong></p>
			<p>长园深瑞积极承担了一大批国家级重点输变电工程和国家重点工程，如：长江三峡水利枢纽工程、西电东输、川藏联网、藏中联网工程、1000kV特高压示范工程、哈密南±800kV直流输电、西北750kV工程、云南500kV鲁西换流站、沈大高速公路、北京奥运会等；同时长园深瑞在石油石化（大庆石化、胜利油田等）、轨道交通（哈齐客专、京沈高铁等）、钢铁冶金（首都钢铁等）、新能源发电（大同沉陷区1GW光伏、阳泉沉陷区1GW光伏、江苏龙源150MW海上风电项目）等领域高效完成诸多重点项目，获得业界一致好评；公司逐渐深入海外市场布局，成功参与多项国际重点项目及“一带一路战略重点工程”，如：泰国首座智能变电站NONGKI站、埃塞俄比亚电网首都配电项目、印度电网首个±800kV直流输电项目、克里米亚220kV海陆缆项目、巴基斯坦默蒂亚里-拉合尔660kV直流输电项目等。</p>

			<p>未来，在服务全球能源、致力于民族高科技产业发展的道路上，长园深瑞将保持技术、质量、服务、管理的优势，不断追求卓越，推进能源革新发展，谱写行业智能化、专业化未来。</p>
		</div>
		<div class="contact box">
			<h4 class="title">联系我们</h4>
			<p>公司地址：深圳市南山区高新技术产业园北区科技北一路13号</p>			
			<p>电话：0755-33018888</p>
			<p>传真：0755-33018889</p>			
			<p>工程服务热线：400-678-8099</p>						
		</div>
		<foot-note></foot-note>
	</div>
</template>
<script type="text/javascript">
	import Vue from 'vue';
	import HomeHeader from './HomeHeader'
	import FootNote from './Foot'
	export default{
		name:'about',
		data(){
			return {

			}
		},
		components:{
			HomeHeader,	
			FootNote
		},
		methods:{

		},
		mounted:function(){	
			var _this = this;
			this.$bus.$emit('activeIndex','5');
		}
	}
</script>
<style scoped>
	.box{
		max-width: 1200px;
		margin: 15px auto;
		padding: 15px 10px;
		/* background-color: #208C7D; */
		background-color: #fff;
		border: 1px solid #666;
		/* color: #fff; */
		text-align: initial;
		border-radius: 5px;
	}
	.box p{
		text-indent: 2em;
	}
	.box p:not(:last-child){
		margin-bottom: 15px;
	}
	.box .title{
		text-align: center;
		margin-bottom: 10px;
		color: #208C7D;
	}
	.contact p:not(:last-child){
		margin-bottom: 5px;
	}
</style>