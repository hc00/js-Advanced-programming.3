<template>
	<div id="rightBar" v-show="isShow">
		<div class="">
			<template>
	  			<el-tabs v-model="activeName" type='card' @tab-click="handleClick">
			    		<el-tab-pane label="管理参数" name="first">
			    			<template>						 
						  <el-table    :data="manageData"    border :show-header=false tooltip-effect="dark"   style="" max-height='744'>
			    			<el-table-column      prop="name"      label="name"       align="center">    </el-table-column>
			    			<el-table-column      prop="value"      label="value" align="center" show-overflow-tooltip>    </el-table-column>
			  			</el-table>
						</template>
			    		</el-tab-pane>
			    		<el-tab-pane label="设计参数" name="second">
			    			<template>						 
						  <el-table    :data="designData"    border :show-header=false tooltip-effect="dark"    style="" max-height='744'>
			    			<el-table-column      prop="name"      label="name"       align="center">    </el-table-column>
			    			<el-table-column      prop="value"      label="value" align="center">    </el-table-column>
			  			</el-table>
						</template>		    						
			    		</el-tab-pane>
			    		<el-tab-pane label="量测数据" name = "third" v-if = 'measurationIsShow'>
			    			<el-table    :data="ycData"    border :show-header=false tooltip-effect="dark"   style="margin-bottom:1px;" max-height='744'>
			    				<el-table-column label="遥测信息">
			    					<el-table-column      prop="Name"      label="Name"      align="center" show-overflow-tooltip>    </el-table-column>
				    				<el-table-column      prop="Value"      label="Value"       align="center">    </el-table-column>
				    				<!-- <el-table-column      prop="system"      label="系统" align="center">    </el-table-column> -->
				    				<el-table-column      label="系统" align="center">
									<template slot-scope="scope"><div class="cell"> {{ scope.row.system == "1"?'主控':'辅控' }}</div></template>    
								</el-table-column>
			    				</el-table-column>			    			
				  		</el-table>
				  		<!-- <el-table    :data="yxData"    border    style="" max-height='245'>
				    			<el-table-column label="遥信信息">
			    					<el-table-column      prop="Name"      label="Name"      align="center">    </el-table-column>
				    				<el-table-column      prop="Value"      label="Value" align="center">    </el-table-column>
			    				</el-table-column>
				  		</el-table>	 -->	    
			    		</el-tab-pane>
	  			</el-tabs>
			</template>
		</div>
	</div>
</template>
<script>
	import Vue from 'vue'	
	import {Tabs,TabPane,Card,Table,TableColumn,Loading} from'element-ui'
	Vue.use(Tabs,TabPane,Card,Table,TableColumn,Loading)
	export default {
		name:"RightBar",
		props:['bimEngine'],
		data(){
			return {
				activeName: 'first',				
				manageData:[],		//管理数据
				designData:[],			//设计数据
				ycData:[],			//遥测
				yxData:[],			//遥信
				isShow:false,			//右侧模块是否显示
				measurationIsShow:false	//量测数据是否显示			
			}
		},
		components:{
			// 'el-tabs':Tabs,
			'el-tab-pane':TabPane,
			'el-table':Table,
			'el-table-column':TableColumn
		},
		methods:{
			handleClick(tab, event) {
				// console.log(tab, event);
			}
		},
		created(){
			var _this = this;	
			this.$bus.$on('rightBarShow',function(data){
				_this.isShow = data;
			});	
			this.$bus.$on('measurationIsShow',function(data){
				_this.measurationIsShow = data;
			});	
			//监听获取管理数据
			this.$bus.$on('sendManageData',function(data){
				_this.manageData = data;
			});
			//监听获取设计数据
			this.$bus.$on('sendDesignData',function(data){
				// console.log(data,this)
				_this.designData = data;
			});
			//监听获取遥测信息数据
			this.$bus.$on('sendYcData',function(data){//alert(1)
				_this.ycData = data
			});

			/*//监听获取遥信信息数据
			this.$bus.$on('sendYxData',function(data){
				_this.yxData = data
			});*/
		},
		mounted(){
			/*console.log($('#content canvas[tabindex="-1"]'))
			console.log($('#content canvas'))*/
		},
		beforeDestroy(){
			// this.bimEngine = null;
			this.$bus.$off('rightBarShow');
			this.$bus.$off('measurationIsShow');
			this.$bus.$off('sendManageData');
			this.$bus.$off('sendDesignData');
			this.$bus.$off('sendYcData');
		},
		watch:{			
			isShow:function(newValue,oldValue){//console.log(this.bimEngine)
				if(newValue === true ){
					// $(".main #content").css('margin','0 20%')
					$(".main #content").css('width','60%')
				}else{
					// $(".main #content").css('margin','0 0 0 20%')
					$(".main #content").css('width','80%')					
				};
				var width = $(".main #content").width();
				// $('#content canvas')[3].style.width = width+'px';
				this.bimEngine.getBimEngine().resize(width,800)
			},
			
		}
	}
</script>
<style >
	#rightBar{
		width:calc(20% - 5px);
		height:800px;
		float:right;
		background:#fff; 		
	}	
	.el-tabs__item{
		color: #bbb;
	}
	.el-tabs__item.is-active {
	    	color: #fff !important;
	    	background-color: #208c7d;	    	
	}
	.el-tabs__item:not(.is-active):hover{
		color: #208C7D;
	}
	.el-table-pane{}
	#rightBar .el-table{
		width: 98%;
    		margin: 0 auto;
	}
	#rightBar .el-table__header-wrapper {
		display: none;
	}
</style>