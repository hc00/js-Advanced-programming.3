<template>
	<div id="head" class="clearfix">
		<div class="logo left">
			<div class="img left"><img src="../assets/logo2.png" alt="logo" width='100%' height="100%"></div>			
			<div class="left name">上海电力公司220KW东喣站</div>
		</div>	
		<div class="msg right">
			<div class="left time">
				<span style="font-size:18px;">{{timehms}}</span><br>
				<span>{{timeymd}}</span>
			</div>
			<div class="right user">				
				<el-dropdown style="line-height:40px;" >
  					<span class="el-dropdown-link">{{username}}<i class="el-icon-arrow-down el-icon--right"></i></span>
  					<el-dropdown-menu slot="dropdown" >
    						<el-dropdown-item v-if='superuser'><router-link to="/account" class="editAccount">账号管理</router-link></el-dropdown-item>
    						<el-dropdown-item><span @click="editPsd">修改密码</span></el-dropdown-item>
    						<el-dropdown-item ><span  @click='signOut'>退出</span></el-dropdown-item>    
  					</el-dropdown-menu>
				</el-dropdown>
			</div>
		</div>	
		<!-- background-color="#208C7D" -->
		<div class="nav">
			<el-menu
				  :default-active="activeIndex"
				  class="el-menu-demo"
				  mode="horizontal"
				  @select="handleSelect"
				  
				  text-color="#fff"
				  active-text-color="#208C7D">
			  	<el-menu-item index="1"><router-link to="/index">三维监测</router-link></el-menu-item>
			  	<el-menu-item index="2"><router-link to="/wiringDiagram">接线图</router-link></el-menu-item>
			  	<el-menu-item index="3"><router-link to="/alarm">实时告警</router-link><div class="alarmImg" v-if='hintMsg'><img src="../assets/on.png" alt="" width='100%'></div></el-menu-item>
			  	<el-menu-item index="4"><router-link to="/hisalarm">历史查询</router-link></el-menu-item>
			  	<el-menu-item index="5"><router-link to="/about">关于我们</router-link></el-menu-item>			  	
			  	<!-- <li role="menuitem" class=" about" style="color: rgb(255, 255, 255); border-bottom-color: transparent; "><a href="http://www.sznari.com/main/about/" target='_blank'>关于我们</a></li>			  	 -->
			</el-menu>
		</div>
		<el-dialog class="editPsd" center  title="修改密码" :visible.sync="dialogVisible" width="40%" @close='close'> 
		  
			<el-form :model="ruleForm" status-icon :rules="rules" ref="ruleForm" label-width="80px" class="demo-ruleForm">
				<el-form-item label="旧密码" prop="oldPass">
				    	<el-input type="password" v-model="ruleForm.oldPass" auto-complete="off"></el-input>
				</el-form-item>
  				<el-form-item label="新密码" prop="pass">
    					<el-input type="password" v-model="ruleForm.pass" auto-complete="off"></el-input>
  				</el-form-item>
  				<el-form-item label="确认密码" prop="checkPass">
    					<el-input type="password" v-model="ruleForm.checkPass" auto-complete="off" @keyup.enter.native="submitForm('ruleForm')"></el-input>
  				</el-form-item> 
			</el-form>  
		  	<span slot="footer" class="dialog-footer">		    				    		
		    		<el-button type="primary" @click="submitForm('ruleForm')">修改</el-button>
		    		<el-button @click="dialogVisible = false">取 消</el-button>
		  	</span>
		</el-dialog>	
	</div>
</template>
<script>
	import Vue from 'vue'
	import EditPsd from './editPsd'
	import {Menu,Submenu,MenuItem,Dialog,Form,FormItem,Input,Button,Dropdown,DropdownMenu,DropdownItem} from 'element-ui'
	Vue.use(Menu,Submenu,MenuItem,Dialog,Form,FormItem,Input,Button,Dropdown,DropdownMenu,DropdownItem)
	export default {
		name:"HomeHeader",
		// props:['bimviz','bimvizLoadCompleted'],
		computed:{
			
		},		
		data(){	
			//修改密码验证
			var validateOldPass = (rule, value, callback) => {
	        		if (value === '') {
	          			callback(new Error('请输入旧密码'));
	        		} else {	          			
	          			callback();
	        		}	
	      	};
			var validatePass = (rule, value, callback) => {
	        		if (value === '') {
	          			callback(new Error('请输入密码'));
	        		} else {
	          			if (this.ruleForm.checkPass !== '') {
	            			this.$refs.ruleForm.validateField('checkPass');
	          			}
	          		callback();
	        		}	
	      	};
	      	var validatePass2 = (rule, value, callback) => {
	        		if (value === '') {
	          			callback(new Error('请再次输入密码'));
	        		} else if (value !== this.ruleForm.pass) {
	          			callback(new Error('两次输入密码不一致!'));
	        		} else {
	          			callback();
	        		}
	      	};		
			return {
				msg:'',				
				activeIndex:'1',				
				timehms:'00:00:00',			//时分秒
				timeymd:'2018/00/00',		//年月日
				username:'',				//登录用户名
				superuser:false,			//账号权限
				dialogVisible: false,			//dialog弹窗
				hint:false,				//告警信息是否全部确认
				hintMsg:false,				//警告灯状态
				ruleForm: {				//表单验证数据
					oldPass:'',
    					pass: '',
    					checkPass: '',          
  				},
  				rules: {					//表单验证规则 
  					oldPass: [
        					{ required: true,validator: validateOldPass, trigger: 'blur' }
      				],
    					pass: [
      					{ required: true,validator: validatePass, trigger: 'blur' }
    					],
    					checkPass: [
      					{ required: true,validator: validatePass2, trigger: 'blur' }
    					],          
  				},
    				intervalLists:[],			//告警间隔
    				alarmCarousel:[],			//告警轮播数据
  				alarmData:[],				//实时告警信息
				prevAlarmData:[],			//localstorage中保存的上次告警状态信息				
				prevFlashData:[],			//localstorage中保存的上次闪动信息
				idLists:[],					//闪亮构件id
				flashData:[],				//闪亮构件数组[{globalId:'',Level:'',...},{}]
				bimviz:null,
				bimvizLoadCompleted:false,
				firstLoad:true,					
				bimEngine:null, 			//3D引擎实例
				bimvizRGBA:{				//告警闪烁颜色
					warning:[0.90196,0.62529,0.23529,1.0],			//异常
					danger:[0.96078,0.42353,0.42353,1.0],			//事故
					primary:[0.25098,0.61961,1,1.0]
				},
				checkedVisibleKeys:[],			//当前选中的显示列表（显示tree）
				keepalive:false,
				elementList:{},				//id：构件列表
			}
		},
		components:{
			'el-menu':Menu,
			'el-menu-item':MenuItem,
			'el-submenu':Submenu,
			'el-dialog':Dialog,
			'el-form':Form,
			'el-form-item':FormItem,
			'el-input':Input,
			'el-button':Button,
			'el-dropdown':Dropdown,
			'el-dropdown-menu':DropdownMenu,
			'el-dropdown-item':DropdownItem
		},
		methods:{
			//头部导航组件选择后回调
			handleSelect(key, keyPath) {
      			// console.log(key, keyPath,key === "5");        				
    			},
    			//获取当前时间 yyyy/MM/dd hh:mm:ss
    			getNowTime(){
    				var nowTime = new Date().format();
    				nowTime = nowTime.split(" ");
    				this.timehms = nowTime[1];
    				this.timeymd = nowTime[0];
    			},    
    			//弹出修改密码dialog   			
    			editPsd(){
    				this.dialogVisible = true;
    			},
    			//退出登录 
    			signOut(){   
    				var _this = this;
    				this.MessageBox.confirm('确定要退出此账号吗?', '提示', {
    					confirmButtonText: '确定',
    					cancelButtonText: '取消',
    					type: 'warning',
    					center: true
    				}).then(() => {    				
    					this.cookie.clear();
    					this.$router.push('/');
        				_this.Message({
          					type: 'success',
          					message: '退出成功!',
          					duration:300,
          					onClose:function(msg){       //console.log(1)   
        						location.reload();
          					}
      				});
        				// location.reload();
    				}).catch((err) => {
    					console.log(err)
    					_this.Message({
      					type: 'info',
      					message: '已取消退出'
    					});
    				});   				
    				// this.$bus.$emit('signOut',[true,_this.$router]);
    			},
      			/*handleClose(done) {
        				this.$confirm('确认关闭？') .then(_ => {
            				done();
          				}).catch(_ => {});
  			},*/
  			//关闭dialog前重置表单
  			close(){
  				this.$refs['ruleForm'].resetFields();
  			},
  			//修改密码并提交
  			submitForm(formName) {
  				var _this = this;
      			this.$refs[formName].validate((valid) => {
        				if (valid) {            					
          					_this.axios.post(`${this.dataApi}/updateUser`,{
          						username:_this.username,
          						oldPassword:_this.ruleForm['oldPass'],
        						newPassword:_this.ruleForm['pass']          						
          					}).then(function(res){console.log(res)
          						var data = res.data;
          						if(data == 1){
          							_this.MessageBox.alert('请重新登录', '提示', {
						          		confirmButtonText: '确定',
						          		callback: action => {
						            		_this.$router.push('/')
						          		},
						          		center:true
						        	});
          						}else if(data== -1){
          							_this.MessageBox.alert('密码与原密码重复，请重新设置', '提示', {
						          		confirmButtonText: '确定',
						          		center:true
						        	});
          						}
          					}).catch(function(err){
          						console.log(err)
          					})
        				} else {
          					console.log('error submit!!');
          					_this.MessageBox.alert('请正确填写', '提示', {
				          		confirmButtonText: '确定',					          		
				          		center:true
				        	});
          					return false;
        				}
      			});
      				// this.dialogVisible = false;
    			},
    			resetForm(formName) {
      				this.$refs[formName].resetFields();        				
    			},
    			getLoginUserCookie(){
    				var cookieUserName = this.cookie.get("userName");
				if(cookieUserName){
					this.username = cookieUserName;
					this.superuser = this.cookie.get("superUser") === 'true';				
				}else{
					this.$router.push('/')
				};
			},
			getAlarm(){			//console.log(new Date().format('yyyy-MM-dd hh:mm:ss'))
				var str = localStorage.getItem('alarmStr');
				var flashStr = localStorage.getItem('flashStr');
				// var prevIdStr = localStorage.getItem("idStr");
				this.prevAlarmData = JSON.parse(str);
				this.prevFlashData = JSON.parse(flashStr);
				// this.prevIdData = JSON.parse(prevIdStr);

				var _this = this;
				this.axios.get(`${this.dataApi}/alarm`).then(function(data){
					// console.log(data,_this.prevAlarmData);
					var arr = [],Data=data.data;
					if(Data === "" || Data.length === 0){
						//没有实时告警数据，清除构件亮闪计时器
						if(window.timer && _this.prevFlashData != null && _this.prevFlashData.length != 0){		//console.log(255)
							_this.resetBimviz(_this.prevFlashData);
							localStorage.removeItem('flashStr');
							localStorage.removeItem('idStr');
						};
						_this.hintMsg = false;
						_this.alarmCarousel = [];
						_this.$emit('alarmCarousel',_this.alarmCarousel);	
						return false;
					};	
					for(var i = 0; i < Data.length; i++){
						var key = Data[i][0] + Data[i][2];
						switch(Data[i][4]){
							case '1':
								Data[i][4] = '事故';
								break;
							case '2':
								Data[i][4] = '异常';
								break;
							case '3':
								Data[i][4] = '越限';
								break;		
							case '4':
								Data[i][4] = '变位';
								break;	
							case '5':
								Data[i][4] = '告知';
								break;	
						};
						for(var k in _this.elementList){
							if(Data[i][6] !== null && Data[i][6] == k){
								Data[i][6] = _this.elementList[k]
							}
						};
						arr.push({
							Name:Data[i][0],
							State:Data[i][1],
							Time:Data[i][2],
							Device:Data[i][3],
							Level:Data[i][4],
							System:Data[i][5],
							globalId:Data[i][6],
							id:key,
							readState:'未确认'
						})
					};

					//和上次数据相比较，判断设定信息状态
					if(_this.prevAlarmData != null && _this.prevAlarmData.length != 0  ){
						arr.forEach(function(item1,index1,arr1){
							_this.prevAlarmData.forEach(function(item2,index2,arr2){
								if(item1['id'] === item2['id']){									
									item1['readState'] = item2['readState']
								}
							});							
						})
					};					
					_this.alarmData = arr;
					//检查告警信息是否全部确认进行后续操作
					_this.checkHint(arr);					
					
					// 将本次告警数据保存至localStorage
					var alarmStr = JSON.stringify(arr);					
					localStorage.setItem('alarmStr',alarmStr);
										
				}).catch(function(err){
					console.log(err);
          					// _this.Message('未能成功获取报警信息');
				})
			},
			checkHint(arr){	
				var _this = this;
				// var hint = false;
				this.alarmData.forEach(function(item){		//console.log(item['readState'])
					if(item['readState'] === '未确认'){
						_this.hint = true;													
					};
				});	
				//此时有未确认告警				
				if(this.hint){					
					var _this = this,idLists=[];
					this.hintMsg = true;				//显示告警灯

					//首页时传递轮播数据，对应构件设置闪亮（跳转到非首页时已清除动画)
					if(this.$route.path === "/index"){		console.log('index  flash')
						function checkState(item) {    	
	    						return item['readState'] === '未确认';
						};
						var data = arr.filter(checkState);			//筛选出未确认的数据					
						if(data.length <= 5){
							this.alarmCarousel = data;
						}else{
							this.alarmCarousel=data.slice(0,5);
						};
						this.$emit('alarmCarousel',this.alarmCarousel);	//传递轮播数据
						data.forEach(function(item){				//遍历保存非空 闪亮idLists
							if(item['globalId'] != null){
								idLists.push(item['globalId']);
							};							
						});

						/*------------------------------------------------------------------------------*/
						//未确认告警数据的id和当前显示数据相比较，求交集；不为空则进行闪亮
						var arr = this.intersection(this.checkedVisibleKeys,idLists);		console.log(arr,'交集',idLists,data,this.checkedVisibleKeys.length)
						if(arr.length > 0){					//console.log(arr.length)
							//过滤出当前显示的可闪数据
							var result = [];		
							arr.forEach(function(id){	
								data.filter((item)=>{									
									if(item['globalId'] == id){			
										result.push(item)
									}
								});
							});
							this.idLists = arr;				
							this.flashData = result;
							//向home.vue传递当前高亮数据
							this.$emit('sendFlashData',this.flashData);							
							//构件高亮闪动
							this.setBIMVIZRGBA(data);	
								
						}
						
						/*------------------------------------------------------------------------------*/
						/*this.idLists = idLists;				//console.log(this.idLists,data)
						this.flashData = data;
						this.$emit('sendFlashData',this.flashData);
															
						this.setBIMVIZRGBA(data,idLists);				//构件高亮闪动	
						// 将本次闪动数据保存至localStorage
						var flashStr = JSON.stringify(data);							
						var idStr = JSON.stringify(this.idLists);					
						localStorage.setItem('flashStr',flashStr);
						localStorage.setItem('idStr',idStr);*/
					};				
				//全部已确认后灭灯（确认前已关闭动画，此时无需再次清除）	
				}else{						
					this.hintMsg = false;
					this.alarmCarousel = [];
					this.$emit('alarmCarousel',this.alarmCarousel);
									
				};
			},
			setBIMVIZRGBA(list){		console.log('setbim')
	          		var _this = this;//console.log(this.prevFlashData != null && this.prevFlashData.length != 0)	          			
          			if(this.bimvizLoadCompleted){	//3D引擎加载完成          				
          				//当前有闪动，先清除上次
          				if(window.timer){
          					this.resetBimviz(this.prevFlashData);
          				};	          			
	          			// 将本次闪动数据保存至localStorage
					var flashStr = JSON.stringify(this.flashData);							
					var idStr = JSON.stringify(this.idLists);					
					localStorage.setItem('flashStr',flashStr);
					localStorage.setItem('idStr',idStr);
					//将本次数据对应构件边变色闪动
	          			list.forEach(function(item,index){
	          				if(item['Level'] === '异常'){
	          					_this.bimviz.getBimEngine().changeElementRGBA(item['globalId'],_this.bimvizRGBA['warning'])
	          				}else if(item['Level'] === '事故'){
	          					_this.bimviz.getBimEngine().changeElementRGBA(item['globalId'],_this.bimvizRGBA['danger'])
	          				}else{
	          					_this.bimviz.getBimEngine().changeElementRGBA(item['globalId'],_this.bimvizRGBA['primary'])
	          				};
	          			});
	          			this.flashInterval(this.idLists);		          			
	          		};		          				          		
	          },
	          //重置构件颜色并清除计时
	          resetBimviz(list){
	          		var _this = this;
	          		clearInterval(window.timer);
	          		window.timer = null;			//console.log(_this,_this.bimviz.getBimEngine(),_this.bimEngine,422)
	          		list.forEach(function(item){
	          			_this.bimviz.getBimEngine().resetElementRGBA(item['globalId']);
	          		});
	          		//清除localStorage保存的数据
	          		localStorage.removeItem('flashStr');
				localStorage.removeItem('idStr');
	          		//_this.idLists = [];		          		
	          },
	          flash(list){      console.log('falsh')  
                	var _this = this;
                	this.bimviz.getBimEngine().setElementListVisible(list,false)
    				var t1 = setTimeout(function(){
                        	_this.bimviz.getBimEngine().setElementListVisible(list,true)
                	},1000);                   
	          },
	          //告警对应构件闪动
	          flashInterval(idLists){		          		
	          		clearInterval(window.timer);
                    	this.flash(idLists);
                    	window.timer = setInterval(this.flash,2000,idLists); 
                    	return timer;
	          },
	          //2个数组的交集
	          intersection(arr1,arr2){
				var set1 = new Set(arr1);	//console.log(set1.size)
	    			var set2 = new Set(arr2);
	    			var subset = [];
	    			
	    			if(set1.size > set2.size){
	    				for (let item of set1) {
		        			if (set2.has(item)) {
		            			subset.push(item);
		        			}
		    			};
	    			}else if(set1.size < set2.size){
	    				for (let item of set2) {
		        			if (set1.has(item)) {
		            			subset.push(item);
		        			}
		    			};
	    			}
	    			return subset;
			},
			//接收sidebar传递的勾选节点
			acceptVisible(data){
				var _this = this;
				console.log(123456,data.length,window.timer)				
				_this.checkedVisibleKeys = data;
				//如果有动画
				if(window.timer){
					var arr = _this.intersection(data,_this.idLists);
					//当部分构件被隐藏，清除开始新的动画
					if(arr.length > 0 && arr.length != _this.idLists.length){	
						//过滤出当前显示的可闪数据
						var result = [];		
						arr.forEach(function(id){	
							data.filter((item)=>{									
								if(item['id'] == id){			
									result.push(item)
								}
							});
						});
						_this.idLists = arr;				
						_this.flashData = result;
						//向home.vue传递当前高亮数据
						_this.$emit('sendFlashData',_this.flashData);							
						//构件高亮闪动
						_this.setBIMVIZRGBA(data);	

					//构件全部被隐藏，清除		
					}else if(arr.length == 0){		
						_this.resetBimviz(_this.flashData);
					}
				}
			},
			//获取构件存储列表
			getElementInfo(){
				var _this = this;
				this.axios.get(`${_this.dataApi}/elementinfo`).then(function(res){
					console.log(res);
					_this.elementList = res.data;
				}).catch(function(err){
					console.log(err)
				});
			}
		},
		created(){		console.log(33333,'header created')
			//监听菜单导航默认选中值
			var _this = this;
			this.$bus.$on('activeIndex',function(data){
				_this.activeIndex = data;
			});
			this.$bus.$on('hint',function(data){
				_this.hintMsg = data;	
				_this.$emit('alarmCarousel',[]);				
			});

			//接收visibleTree显示的构件数据
			this.$bus.$on('visibleChecked',this.acceptVisible);				
			
			//接收bimviz实例
			this.$bus.$on('sendBimviz',function(data){	
				_this.bimviz = data;
				_this.bimEngine = _this.bimviz.getBimEngine();	//console.log(_this.bimEngine)
			});
			//接收引擎模型加载状态
			this.$bus.$on('sendLoadCompleted',function(data){	
				_this.bimvizLoadCompleted = data;
			});					
		},
		mounted(){			console.log(Date.now(),'header mounted')	
			var _this =this;window.$header = this;

			//获取构件映射
			this.getElementInfo();
			//获取当前时间并格式化
			this.getNowTime();
			window.nowTime = setInterval(this.getNowTime,1000);

			//检索cookie如果登录则保存用户名和权限值
			this.getLoginUserCookie();

			//组件传递登录用户名
			this.$emit('sendUser',this.username);
			
			//非实时告警页面 定时请求
			if(this.$route.path !== "/alarm"){
				setTimeout(function(){
					_this.getAlarm();				
					window.flashTimer = setInterval(_this.getAlarm, 90*1000);
				},2500)
			};			
			setTimeout(function(){
				_this.keepalive = true;
			},500);		
		},
		activated(){	console.log('HomeHeader activated归来',this.keepalive)
			if(this.keepalive === true){	
				window.$header = this;		
				var _this =this;
				this.hint = false;

				//获取构件映射
				this.getElementInfo();

				//获取当前时间并格式化
				this.getNowTime();
				window.nowTime = setInterval(this.getNowTime,1000);

				//检索cookie如果登录则保存用户名和权限值
				this.getLoginUserCookie();

				//组件传递登录用户名
				this.$emit('sendUser',this.username);
				
				// this.$bus.$on('visibleChecked',_this.acceptVisible);
				//非实时告警页面 定时请求
				if(this.$route.path !== "/alarm"){
					this.getAlarm();				
					window.flashTimer = setInterval(_this.getAlarm, 90*1000);					
				};				
			}	
		},
		deactivated(){		console.log('home-header  离开',Date.now())

		},	
		beforeDestroy(){	
			var _this = this;						
			// this.bimviz = null;
			// this.bimEngine = null;			
			// 告警计时
			clearInterval(window.flashTimer);
			window.flashTimer = null;
			//构件闪烁计时
			if(window.timer){
				this.resetBimviz(this.flashData);
			};
			
			// 时间计时器
			clearInterval(window.nowTime);
			window.nowTime = null;	
			this.$bus.$off('visibleChecked',_this.acceptVisible);			
		},
		destroyed(){
			console.log(window.timer,window.flashTimer);
		},
		watch:{
			/*bimviz:function(newValue,oldValue){var _this = this;	//alert(1234)			
				if(newValue !== undefined ){//console.log(new Date().format())
					this.bimEngine = this.bimviz.getBimEngine();	//console.log(new Date().getTime(),this.bimEngine)
					//3D引擎加载完成后判断执行首次高亮					
					if(this.hint){	//有未确认
						this.flashData.forEach(function(item,index){
		          				if(item['Level'] === '异常'){
		          					_this.bimEngine.changeElementRGBA(item['globalId'],_this.bimvizRGBA['warning'])
		          				}else if(item['Level'] === '事故'){
		          					_this.bimEngine.changeElementRGBA(item['globalId'],_this.bimvizRGBA['danger'])
		          				}else{
		          					_this.bimEngine.changeElementRGBA(item['globalId'],_this.bimvizRGBA['primary'])
		          				}
		          			});
		          			this.flashInterval(this.idLists);
					};					
				};					
			},*/			
		},

	}
</script>
<style scrope>
	#head{
		box-sizing: border-box;
		width: 100%;
		padding: 10px 15px;
		height: 60px;
		background-color: #208C7D;
		color: #fff;
	}	
	.logo .img,.logo .cyg{
		width: 120px;
		height: 40px;
		margin-right: 15px;
	}
	.logo .name{
		height: 40px;
		line-height: 40px;
		/* margin-left: 10px; */
	}
	#head .msg{
		width: 200px;
	}
	.msg .time{
		line-height: 20px;
	}
	#head .nav{
		width: 450px;
		margin: 0 auto;		
	}
	#head ul{
		width: 380px;
		margin: 0 auto;
		/* padding-top: 10px;		 */
		border: none 0;
		background-color: #208C7D;
	}	
	#head li{
		padding: 0 10px;
		height: 40px;
		line-height: 40px;
		border: none 0;
		position: relative;
		background-color: rgb(32, 140, 125);
	}
	#head li:hover{		
		background-color: rgb(26, 112, 100);
		cursor: pointer;
	}
	#head li a{
		display: block;
	}
	.alarmImg{
		position: absolute;
		width: 12px;
		height: 15px;
		right: -2px;
		top: -7px;
		z-index: 999;
	}	
	#head .is-active{
		background-color: #fff !important;
	}	
	/* #head .about{
			float: left; 		
		}
		#head .about a{
			color: #fff;
			font-size: 14px;
		}
		#head .about:hover{		
			background-color: rgb(26, 112, 100);
			cursor: pointer;
		} */	
	.el-dropdown-menu{
		z-index: 9999 !important;
	}
	.el-dropdown{
		color: #fff !important;
	}
	.editPsd .el-dialog{
		position: absolute;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
		margin: auto !important;
		height: 350px;
		border-radius: 10px;
	}
	.editAccount{
		color: #606266;
	}

</style>
