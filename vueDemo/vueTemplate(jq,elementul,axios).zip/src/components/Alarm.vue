﻿<template>
	<div class="wrapper">
		<home-header></home-header>
		<div class="alarm">

			<div style="margin: 15px auto;text-align: left;width:90%;">    				
    				<el-button @click="setRead()">确认告警</el-button>
    				<el-select v-model="stateValue"   style="width:120px">
			    		<el-option v-for="item in stateData" :key="item.value" :label="item.label" :value="item.value">
			    		</el-option>
			  	</el-select>
    				<!-- <el-button @click="toggleSelection()">状态选择</el-button> -->
  			</div>

			<el-table    :data="alarmData" ref="multipleTable"  tooltip-effect="light" :row-class-name="tableRowClassName"  :cell-class-name='tableCellClass'
			 @selection-change="handleSelectionChange"    border    style="width:90%;margin:0 auto" max-height='750' height='750'>
				<el-table-column label="报警信息">
					<el-table-column      type="selection"      width="40"></el-table-column>					
					<el-table-column      prop="Time"      label="时间" align="center">    </el-table-column>
					<el-table-column      prop="Interval"      label="设备" align="center">    </el-table-column>
					<el-table-column      prop="Level"      label="等级" align="center" width='80'>    </el-table-column>
					<el-table-column      prop="Name"    label="名称"  align="center" show-overflow-tooltip>    </el-table-column>
					<el-table-column           label="状态" align="center" width='80'>
						<template slot-scope="scope"><div class="cell"> {{ scope.row.State === '1'?'动作':'复归' }}</div></template>    
					</el-table-column>
					<el-table-column           label="系统" align="center" width='80'>
						<template slot-scope="scope"><div class="cell"> {{ scope.row.System === "1"?'主控':'辅控' }}</div></template>    
					</el-table-column>	
					<el-table-column align='center' prop="readState"  label="确认状态" width="100"  >
      						<template slot-scope="scope">
      							<strong v-if="scope.row.readState === '未确认'" >{{scope.row.readState}}</strong>
      							<span v-else>{{scope.row.readState}}</span>
        							<!-- <el-tag size="mini"
          								:type="scope.row.readState === '未确认' ? 'info' : 'success'"
          								disable-transitions>{{scope.row.readState}}</el-tag> -->
      						</template>
    					</el-table-column>
				</el-table-column>			    			
	  		</el-table>
	  		
		</div>
		<foot-note></foot-note>
	</div>
</template>
<script type="text/javascript">
	import Vue from 'vue';
	import HomeHeader from './HomeHeader'
	import FootNote from './Foot'
	import { Table,TableColumn,Loading,Tag,Button,Select,Option} from 'element-ui';
	Vue.use(Table,TableColumn,Loading,Tag,Button,Select,Option)
	export default{
		name:"alarm",
		// props:['alarmArr'],
		data(){
			return {
				alarmData:[],
				alarmCacheData:[],
				prevAlarmData:[],
				multipleSelection:[],				//勾选数据
				deviceLists:[],				//告警间隔数据
				loadingInstance:null,
				msgAlert:null,
				stateValue:'0',
				stateData:[{
			        		value:'0',
			        		label:'所有告警'
			        	},{
			        		value:'1',
			        		label:'未确认'
			        	},{
			        		value:'2',
			        		label:'已确认'
			        	}]
			}
		},
		components:{	
			HomeHeader,	
			FootNote,	
			'el-table':Table,
			'el-table-column':TableColumn,	
			'el-tag':Tag,
			'el-button':Button,
			'el-select':Select,
			'el-option':Option,		
		},
		methods:{
			//获取警报设备间隔
			getDevice(){
				let _this = this;
				this.axios.get(`${this.dataApi}/device`).then(function(res){
					//console.log(data)					
					var data = res.data,arr = [];
					for(var key in data){						
						arr.push({
							value:key,
							label:data[key]
						});						
					};					
					_this.deviceLists = arr;
					_this.deviceLists.forEach(function(item1){
						_this.alarmData.forEach(function(item2){
							if(item2['Interval'] == item1['value']){
								item2['Interval'] = item1['label']
							};
						})						
					});
					_this.alarmCacheData = _this.alarmData;					
				}).catch(function(err){
					console.log(err)
				})
			},
			getAlarm(){
				var str = localStorage.getItem('alarmStr');
				this.prevAlarmData = JSON.parse(str);

				var _this = this;
				this.axios.get(`${this.dataApi}/alarm`).then(function(data){
					// console.log(data,_this.prevAlarmData);
					var arr = [],Data=data.data;	
					//如果后台数据为空
					if(Data === "" || Data.length === 0 ){
						//_this.Message('暂无告警信息');						
						/*if(_this.loadingInstance){
							_this.loadingInstance.close();
							_this.loadingInstance = null;	
						};*/
						return false;
					};
					for(var i = 0; i < Data.length; i++){						
						var key = Data[i][0] + Data[i][2] ;	
						switch(Data[i][4]){
							case '1':
								Data[i][4] = '事故';
								break;
							case '2':
								Data[i][4] = '异常';
								break;
							case '3':
								Data[i][4] = '越限';
								break;		
							case '4':
								Data[i][4] = '变位';
								break;	
							case '5':
								Data[i][4] = '告知';
								break;	
						};
						arr.push({
							Name:Data[i][0],
							State:Data[i][1],
							Time:Data[i][2],
							Interval:Data[i][3],
							Level:Data[i][4],
							System:Data[i][5],
							id:key,
							readState:'未确认'
						})
					};					
					//和上次数据相比较，判断设定信息状态
					if(_this.prevAlarmData != null && _this.prevAlarmData.length != 0  ){
						arr.forEach(function(item1,index1,arr1){
							_this.prevAlarmData.forEach(function(item2,index2,arr2){
								if(item1['id'] === item2['id']){									
									item1['readState'] = item2['readState']
								}
							});							
						})
					};					
					_this.alarmData = arr;		//console.log(169,Date.now())
					_this.getDevice();				//设备根据id匹配					
					_this.$nextTick(() => {			//console.log('nextTick',Date.now())
						_this.toggleSelection(_this.alarmData);						
					});	
					// _this.alarmCacheData = arr;

					//检查告警信息是否全部确认
					// _this.checkHint();
					var hint = false;
					arr.forEach(function(item){
						if(item['readState'] === '未确认'){
							hint = true;return false;				
						};
					});			
					if(hint){
						_this.$bus.$emit('hint',true);
					}else{
						_this.$bus.$emit('hint',false);
					};					
					
					// 将本次数据保存至localStorage
					var alarmStr = JSON.stringify(arr);					
					localStorage.setItem('alarmStr',alarmStr)
					//请求成功后关闭loading
					/*if(_this.loadingInstance){
						_this.loadingInstance.close();
						_this.loadingInstance = null;						
					}*/														
				}).catch(function(err){
					console.log(err);									
					// _this.MessageBox.alert('未能成功获取报警信息', '提示', {
     //      						confirmButtonText: '确定',
     //      						center:true,
     //      						type:'error',
     //      						callback: action => {
				 //   //        			if(_this.loadingInstance){						
					// 		// 	_this.loadingInstance.close();
					// 		// 	_this.loadingInstance = null;						
					// 		// }
				 //          		},
     //      					})
				})
			},
			//改变单元格的className
			tableCellClass({row, column, rowIndex, columnIndex}){ 
				/*cell-class-name='classname'   添加到td.class*/
				// console.log(row,column)				
				switch(column['label']){              						//某列
					case '确认状态':    //console.log(rowIndex)
						return 'status-row';
						break;          
					default:
						return '';
				};
			},						
      		//切换选中状态（设置'已确认'状态为选中）
      		toggleSelection(rows) {		//console.log(Date.now(),'toggleSelection')
      			var _this = this;
        			if (rows) {		
          				rows.forEach((row,index) => {		
          					if(row['readState'] == '已确认'){		//console.log(index,Date.now(),this.$refs.multipleTable)
          						this.$refs.multipleTable.toggleRowSelection(row,true);
          					}/*else{
          						this.$refs.multipleTable.toggleRowSelection(row,false);
          					}*/            				
          				});
        			} else {
          				this.$refs.multipleTable.clearSelection();
				};												//console.log('finish',Date.now())	
				/*setTimeout(function(){
	        			_this.setReadDisabled();	        			
	        		},0)*/		
			},
			//选择项发生变化时触发
			handleSelectionChange(val) {				//console.log('selection-change',Date.now())
				var _this = this;
        			this.multipleSelection = val;   
        			if(this.multipleSelection.length === 0){
        				this.toggleSelection(this.alarmData);
        			};     										
	        		setTimeout(function(){
	        			_this.setReadDisabled();	        			
	        		},0)
	        		
      		},
      		//设置已确认信息disabled
			setReadDisabled(){	//console.log('dis',Date.now())
				let trs = $('tbody tr');		//console.log(trs)
				for (let i =0;i<trs.length;i++){
					if($(trs[i]).find('.status-row span').html() == '已确认'){		//console.log(i)
						this.$nextTick(() => {
							$('tbody input')[i].setAttribute('disabled',true);			//console.log(i,$('tbody input')[i].disabled,Date.now())
						});
					}
				};				
			},
			//标记已读
			setRead(){
				// var _this = this;
				var _this = this,flag=true;

				//console.log(this.multipleSelection);
				if(this.multipleSelection.length != 0){
					var arr = this.multipleSelection;
					arr.forEach(function(item,index,arr){
						_this.alarmData.forEach(function(item1,index1){
							if(item['id'] === item1['id']){
								item1['readState'] = "已确认"
							};							
						})
					});
					this.toggleSelection(this.alarmData);
					// this.setReadDisabled();
					//检查告警信息是否全部确认
					this.checkHint();
					//_this.$refs.multipleTable.clearSelection();	//清除所有勾选
					var alarmStr = JSON.stringify(_this.alarmData);					
					localStorage.setItem('alarmStr',alarmStr);
					// console.log(_this.alarmData)
				}else{
					// alert('请选择要标记的内容');
					this.MessageBox.alert('请勾选要确认的信息', '提示', {
          						confirmButtonText: '确定',
          						center:true
          					})
				}
			},
			checkHint(){
				var hint = false;
				this.alarmData.forEach(function(item){
					if(item['readState'] === '未确认'){
						hint = true;return false;				
					};
				});		
							
				if(hint){
					this.$bus.$emit('hint',true);
				}else{
					this.$bus.$emit('hint',false);	
					this.MessageBox.alert('信息已经全部确认', '提示', {
    						confirmButtonText: '确定',
    						center:true
    					});								
					/*this.Message({
          						message: '信息已经全部确认',
          						type: 'success',
          						center:true,
          						duration:0
        					});*/
				};
			},
			/*//筛选确认状态
			filterReadState(value, row, column) {
        				return row.readState === value;
      			},*/
      		//根据告警等级的不同 table 每行设置不同的class 背景色样式
    			tableRowClassName({row, rowIndex}) {			//console.log(row,rowIndex,Date.now()) 
    				if(row['readState'] == '未确认') {
    					switch(row['Level']){
	      				case '事故':
							return 'danger-row';
							break;
						case '异常':
							return 'warning-row';
							break;						
						case '变位':
							return 'primary-row';
							break;	
						case '告知':
							return 'primary-row';
							break;	
						case'越限':
							return 'outLimit-row';
						default:
							return '';
	        			};
	        		};  
      		},
      		interval(func, wait){
	  			var interv = function(){
	    				func.call(null);
	    				window.alarmTimer = setTimeout(interv, wait);
	  			};
	  			window.alarmTimer = setTimeout(interv, wait);
			}	
		},
		mounted:function(){		window.$vm = this;
			// this.getInterval();
			this.$bus.$emit('activeIndex','3');	
			/*this.loadingInstance = Loading.service({
	    			// fullscreen:false,
	    			target:'.alarm',
	    			text:'拼命加载中...',
	    			background:'rgba(0,0,0,.8)'
	    		});*/			
			this.getAlarm();

			if(this.$route.path === "/alarm"){//console.log(this.$route.path)
				// window.interval =setInterval(this.getAlarm,1000*90);
				this.interval(this.getAlarm,1000*90)
			};
		},
		beforeDestroy(){
			clearTimeout(window.alarmTimer);
			window.alarmTimer = null;
		},
		watch:{
			alarmData(newValue,oldValue){
				//console.log(newValue,oldValue,Date.now())
				// this.toggleSelection(newValue);
			},
			stateValue(newValue,oldValue){
				var _this = this;
				switch(newValue){
					case "0": 			//所有告警
						_this.alarmData = _this.alarmCacheData;
						break;
					case "1": 			//未确认告警
						var arr = _this.alarmCacheData.filter(function(item){
							return item['readState'] === '未确认';
						});
						_this.alarmData = arr;
						break;
					case "2": 			//已确认告警
						var arr = _this.alarmCacheData.filter(function(item){
							return item['readState'] === '已确认';
						});
						_this.alarmData = arr;
						break;		
				};
				this.$nextTick(() => {
					_this.toggleSelection(_this.alarmData);
					// _this.setReadDisabled();
				});				
			},
			
		}
	}
</script>
<style scoped>
	.alarm{
		/* width: 1000px; */
		margin: 0 auto;
		padding: 20px 30px;
	}
	.alarm .el-tag--success{
		background-color: #ecf5ff;
	}
	.alarm .el-tag--info{
		color: #303133;
		background-color: #ecf5ff;
	}	
</style>
<style>
	.alarm .el-table .el-table__row {
		background: #909399;
	}
	.alarm .el-table .warning-row{
		background-color: #e6a23c;		
	}
	.alarm .el-table .danger-row{
		background-color: #f56c6c;
	}
	.alarm .el-table .primary-row{
		background-color: #409eff;			
	}
	.alarm .el-table .outLimit-row{
		background: #FFEB3B;
		/* background: #9E9E9E; */
	}
	
</style>
