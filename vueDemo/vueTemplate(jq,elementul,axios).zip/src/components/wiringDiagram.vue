<template>
	<div class="wirngDiagram">
		<home-header></home-header>
		<div class="svg">
			<!-- <embed id='svgView' src="../assets/main-wiring-diagram.svg" type="image/svg+xml" /> -->
			<embed id='svgView' :src="svgUrl" type="image/svg+xml" />						
		</div>
		<foot-note></foot-note>
	</div>
</template>
<script>
	import Vue from 'vue';
	import HomeHeader from './HomeHeader'
	import FootNote from './Foot'
	var svgUrl = require('../assets/wiring.svg');
	export default{
		name:'wiringDiagram',
		data(){
			return {
				svgEl:null,
				// gIdLists:[],
				gInfoLists:[],
				svgUrl,
			}
		},
		components:{
			HomeHeader,	
			FootNote
		},
		methods:{
			addListener(ele,type,handle){
				if (window.addEventListener) {                    //所有主流浏览器，除了 IE 8 及更早 IE版本
    					ele.addEventListener(type, handle);
				} else if (window.attachEvent) {                  // IE 8 及更早 IE 版本
    					ele.attachEvent('on'+type, handle);
				}
			},
			getSVGInfo(){console.log(new Date().format())
				var _this = this;
				_this.axios.get(`${_this.dataApi}/svgsignal`).then(function(data){//console.log(new Date().format('yyyy-MM-dd hh:mm:ss'),data)
					var Data = data.data;
					if(Data !== "" && Data.length !== 0){		//数据非空时进行处理						
						Data.forEach(function(item){
							var parentId = _this.svgEl.getElementById(item[0]).parentNode.getAttribute("id");
							//为变压器除外的电气件刷新状态
							if(parentId.toLocaleLowerCase() != 'powertransformerclass' ){
								var gEle = _this.svgEl.getElementById(item[0]);		//通过Id查找svg内对应g节点
								var href = $(gEle).children('use').attr('xlink:href').split("@")[0]+'@'+item[1];
								$(gEle).children('use').attr('xlink:href',href);			//为g下的use节点‘xlink:href'重新赋值
							};
						})
					};
				}).catch(function(err){
					console.log(err)
					// _this.Message('请求发生错误'+err.message);
				})
			}
		},
		mounted(){console.log(this.svgUrl)
			var _this = this;window.$wd = this;
			this.$bus.$emit('activeIndex','2');				
						
			$('#svgView').on('load',function(){
				var svg =$('#svgView')[0].getSVGDocument();		//console.log(111,svg,76)
				// var svgEl = svg.children[0];window.svgEl =svgEl;
				var svgEl = $(svg).children()[0];window.svgEl =svgEl;				
				_this.svgEl = svgEl;						//svg Dom对象

				
				//为svg添加点击事件
				_this.addListener(_this.svgEl,'click',function(evt){//alert(evt.target.tagName);
					console.log(evt);	
					var svgId = "";				
					if(evt.target.nodeName === 'use'){
          					var parentId = evt.target.parentElement.parentElement.parentElement.getAttribute("id");
          					//如果点击对象为‘三卷变压器’;
          					if(parentId !== null && parentId.toLocaleLowerCase() === 'powertransformerclass' ){
          						//console.log(parentId,true);
          						svgId = evt.target.parentElement.parentElement.getAttribute("id");
          					}else{		//非变压器的开关、刀闸等构件
          						svgId = evt.target.parentElement.getAttribute("id");
          					} ;
          					console.log(svgId)                    					
          				};
          				if(evt.target.parentElement.nodeName === 'g' && evt.target.nodeName === 'path'){
          					console.log(evt.target.parentElement,);
                  				//alert(evt.target.parentElement.getAttribute("id"))
                  				svgId = evt.target.parentElement.getAttribute("id");
          				};//svgId ->string
          				if(svgId !== ""){
          					// svgId = '203';
          					_this.axios.post(`${_this.dataApi}/svg`,{            					
          						svgId:svgId
          					}).then(function(data){
          						console.log(data.data,data.data[svgId]);	//{19: "bd505994-c716-4510-aade-e3015a92748d-0033d94b"}	|| {123:null}
          						if(data.data[svgId] !== null){
          							var globalId = data.data[svgId];
            						_this.$router.push({								    	
					    				name: 'home',
					    				params: {
					        				svgId:globalId
					        		// svgId:'255aa2bf-4492-46cc-b2e7-144cd8929758-000b10c3'
					    				}
								});
          						};
          					}).catch(function(err){
          						console.log(err);
          						//_this.Message('请求发生错误'+err.message);
          					});
          				}
				});
				_this.getSVGInfo();				
				window.svgTimer = setInterval(_this.getSVGInfo, 90*1000);
			});			
		},
		beforeDestroy(){
			clearInterval(window.svgTimer);
			window.svgTimer = null;
		}
	}
</script>
<style>
	.svg{
		padding: 35px 25px 25px;
	}
	#svgView{
		max-height: 800px;
		height: 800px;
		width: 100%;
	}
</style>