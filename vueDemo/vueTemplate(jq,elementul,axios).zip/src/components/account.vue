<template>
	<div class="wrapper">
		<home-header @sendUser='getUser'></home-header>
		<div class="userMsg">
			<el-table    :data="userData" :span-method="objectSpanMethod"    border    style=""  max-height='550'>
				<el-table-column label="账号信息" align='center'>					
					<el-table-column      prop="username"      label="账号" align="center">    </el-table-column>
					<el-table-column            label="密码" align="center">
						<template slot-scope="scope"><span>......</span></template>
					</el-table-column>
					<el-table-column           label="权限" align="center">
						<template slot-scope="scope"><div class="cell"> {{ scope.row.superuser === 1?'超级账号':'普通账号' }}</div></template>    
					</el-table-column>					
    					<el-table-column label="操作" align="center">
    						<el-table-column label="编辑" align="center">
      						<template slot-scope="scope">
        							<el-button  size="mini"
          								@click="handleEdit(scope.$index, scope.row)">修改密码</el-button>
  								<el-button v-if='scope.row.username !=="SystemAdmin" ' size="mini" type="danger"
  								@click="deleteAccount( scope.row.username)">删除账号</el-button>
      						</template>
      						</el-table-column>
      						<el-table-column label="注册" align="center">
      							<template slot-scope="scope"><el-button size="mini" @click='resVisible = true '>注册</el-button>	
      							</template>
      						</el-table-column>
    					</el-table-column>
				</el-table-column>			    			
			</el-table>
			<!-- <el-button>注册</el-button>	 -->
		</div>

		<!-- 注册 -->
		<el-dialog class="register" center  title="注册账号" :visible.sync="resVisible" width="40%" @close='close'>
			 
			<el-form :model="ruleForm" status-icon :rules="rules" ref="ruleForm" label-width="80px" class="demo-ruleForm">
				<el-form-item label="账号" prop="userName">
			    		<el-input type="text" v-model="ruleForm.userName" auto-complete="off" placeholder="请输入账号">
			    		</el-input>
			  	</el-form-item>
			  	<el-form-item label="密码" prop="passWord" >
			    		<el-input type="password" v-model="ruleForm.passWord" auto-complete="off" placeholder="请输入密码" @keyup.enter.native="submitForm('ruleForm')">			    			
			    		</el-input>
			  	</el-form-item>
			  	<el-form-item label="权限" prop="superUser" style="margin-bottom: 0;">
			    		<el-select v-model="ruleForm.superUser" placeholder="请选择">
							<el-option
  								v-for="item in superOptions"  :key="item.value" :label="item.label" :value="item.value">
							</el-option>
						</el-select>
			  	</el-form-item>					 
			</el-form>  
		  	<span slot="footer" class="dialog-footer">			    				    		
		    		<el-button type="primary" @click="submitForm('ruleForm')">注册</el-button>
		    		<el-button @click="resVisible = false">取 消</el-button>
		  	</span>
		</el-dialog>
		<edit-psd :editName = 'editUsername' :dialogVisible.sync='editVisible' :loginName='userName'></edit-psd>
	</div>
</template>
<script>
	import Vue from 'vue'
	import HomeHeader from './HomeHeader'	
	import EditPsd from './editPsd'	
	import {Table,TableColumn,Dialog,Form,FormItem,Input,Button,Tag,Select,Option} from 'element-ui'
	Vue.use(Table,TableColumn,Dialog,Form,FormItem,Input,Button,Tag,Select,Option)
	export default {
		name:'account',
		data(){
			var validateName = (rule,value,callback)=> {
				if(value === ''){
					callback(new Error('请输入账号'));
				};
				callback();
			};
		 	var validatePass = (rule, value, callback) => {
        				if (value === '') {
          					callback(new Error('请输入密码'));
        				} else {
          					
          					callback();
        				}
      			};
      			var validateSuper = (rule, value, callback) => {
        				if (value === '') {
          					callback(new Error('请输入密码'));
        				} else {
          					
          					callback();
        				}
      			};
			return{
				userData:[],
				userName:'',			//当前登录账号
				editUsername:'',
				ruleForm:{
					userName:'',
					passWord:'',
					superUser:null,
				},
				rules:{
					userName:{ required: true,validator: validateName, trigger: 'blur'},
					passWord:{ required: true,validator: validatePass, trigger: 'blur'},
					superUser:{ required: true,validator: validateSuper, trigger: 'blur'}
				},
				superOptions:[{
					value:1,
					label:"超级用户"
				},{
					value:0,
					label:'普通用户'
				}],
				resVisible:false,
				editVisible:false
			}
		},
		components:{
			HomeHeader,	
			EditPsd,	
			'el-table':Table,
			'el-table-column':TableColumn,	
			'el-tag':Tag,
			'el-dialog':Dialog,
			'el-form':Form,
			'el-form-item':FormItem,
			'el-input':Input,
			'el-button':Button,
			'el-select':Select,
			'el-option':Option
		},
		methods:{
			getUser(data){
				this.userName = data;
			},
			getUserInfo(){
				var _this = this;
				this.axios.get(`${this.dataApi}/userInfo`).then(function(res){
					console.log(res)
					_this.userData = res.data;
				}).catch(function(err){
					console.log(err)
				})
			},
			//删除账号操作
			deleteAccount(username){
				console.log(username)
				var _this = this;

  				this.MessageBox.confirm('确定要删除此账号吗?', '提示', {
    					confirmButtonText: '确定',
    					cancelButtonText: '取消',
    					type: 'warning',
    					center: true
    				}).then(() => {
    					_this.axios.post(`${this.dataApi}/deleteUser`,{
    						username:username
    					}).then(function(res){console.log(res)
    						var data = res.data;
    						//删除成功
    						if(data == 1){
    							//删除当前已登录账号
    							if(username === _this.userName){
    								_this.MessageBox.alert('当前登录账号已删除，请重新登录', '提示', {
						          		confirmButtonText: '确定',
						          		callback: action => {
						          			_this.cookie.clear();
						            		_this.$router.push('/');
						          		},
						          		center:true
						        	});
    							//删除列表账号
    							}else{
    								_this.MessageBox.alert('账号已成功删除', '提示', {
						          		confirmButtonText: '确定',							          		
						          		center:true,
						          		callback: action => {
					            			_this.getUserInfo();
					          			},
						        	});
    							};        							
    						};    						
    					}).catch(function(err){
    						console.log(err)
    					})        					
    				}).catch(() => {
      				_this.Message({
        					type: 'info',
        					message: '已取消操作',
        					duration:1500
      				});
    				});   				
			},
			//弹出修改密码dialog
			handleEdit(index, row) {
        			console.log(index, row);
        			this.editUsername = row.username;
        			this.editVisible = true;
      		},  			
      		objectSpanMethod({ row, column, rowIndex, columnIndex }) {
      			var tableLength = this.userData.length;
        			if (columnIndex === 4) {
          				return {
              				rowspan: tableLength,
              				colspan: 1
            			};
        			}
      		},
      		close(){
  				this.$refs['ruleForm'].resetFields();
  			},

  			//注册账号
  			submitForm(formName) {
  				var _this = this;
    				this.$refs[formName].validate((valid) => {
    					if (valid) {            					
      					_this.axios.post(`${this.dataApi}/addUser`,{
      						username:_this.ruleForm['userName'],
      						password:_this.ruleForm['passWord'],
      						superuser:_this.ruleForm['superUser'],
      					}).then(function(res){console.log(res)
      						var data = res.data;
      						if(data == 1){
      							_this.MessageBox.alert('注册成功', '提示', {
						          		confirmButtonText: '确定',
						          		callback: action => {
						            		_this.getUserInfo();
						          		},
						          		center:true
						        	});
      						}else if(data == -1){
      							_this.MessageBox.alert('注册失败，该账号已存在', '提示', {
						          		confirmButtonText: '确定',
						          		center:true
						        	});
      						}
      					}).catch(function(err){
      						console.log(err)
      					})
    					} else {
      					console.log('error submit!!');
      					return false;
    					}
    				});
    				this.resVisible = false;
    			},
    			resetForm(formName) {
      				this.$refs[formName].resetFields();        				
    			}
		},
		created:function(){
			var _this = this;			
		},
		mounted:function(){
			this.$bus.$emit('activeIndex','0');	
			this.getUserInfo();
			
		}
	}
</script>
<style >
	.userMsg{
		padding: 25px ;
	}
	.register .el-dialog{
		position: absolute;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
		margin: auto !important;
		height: 320px;
	}
	.el-dialog--center .el-dialog__body{
		padding: 25px 25px 0 ;
	}
</style>