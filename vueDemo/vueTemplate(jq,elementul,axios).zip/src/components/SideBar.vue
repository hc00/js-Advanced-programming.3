<template>
	<div id="sidebar">	
		<!-- <h4 style="text-align: left;margin:0 0 0 5px;line-height: 30px;">构件列表</h4>	
		<div class="tree">
			<el-input  placeholder="输入关键字进行过滤"  v-model="filterText" size='mini'></el-input>
			<el-tree :data="treeData" :props="defaultProps"  show-checkbox ref='tree' node-key='Id'  
			:filter-node-method="filterNode"@node-click="handleNodeClick" @check="handleCheck"
			 @check-change="handleCheckChange" @current-change="handleCurrentChange"></el-tree>
		</div> -->
		<el-tabs v-model="activeName" type='card' @tab-click="handleClick">
	    		<el-tab-pane label="构件列表" name="list">
	    			<div class="tree">
					<el-input  placeholder="输入关键字进行过滤"  v-model="filterText" size='mini'></el-input>
					<el-tree :data="treeData" :props="defaultProps"  show-checkbox ref='tree' node-key='Id'  
					:filter-node-method="filterNode"@node-click="handleNodeClick" @check="handleCheck"
					 @check-change="handleCheckChange" @current-change="handleCurrentChange"></el-tree>
				</div>
	    		</el-tab-pane>
	    		<el-tab-pane label="显示控制" name="visible">
	    			<div class="tree">
					<!-- <el-input  placeholder="输入关键字进行过滤"  v-model="filterText" size='mini'></el-input> -->
					<el-tree :data="visibleTreeData" :props="defaultProps"  show-checkbox ref='treeVisible' node-key='Id'  
					:filter-node-method="filterNode" :default-checked-keys="['project']" :default-expanded-keys="['project']" @check="treeVisible" ></el-tree>
				</div>	    						
	    		</el-tab-pane>
		</el-tabs>
	</div>
</template>
<script>
	import Vue from 'vue'
	import {Tree,Input,Tabs,TabPane,Card,} from 'element-ui'
	Vue.use(Tree,Input,Tabs,TabPane,Card,)	
	// console.log(Vue)
	export default{
		name:'SideBar',
		props:['modelMain'],
		data(){
			return {
				filterText: '',
				activeName: 'list',									
			    	defaultProps: {
		          		children: 'Children',
		          		label: 'Name'
			   	},
			   	treeData:[{
					Name:'工程项目',
					Id:'project',
					Children:[]
				}],	
				visibleTreeData:[{
					Name:'工程项目',
					Id:'project',
					Children:[]
				}],	
				prevCheckedKeys:[],			//上次勾选后的 构件ID列表（构件列表tree）	   	
				defaultCheckedKeys:[],		//tree加载完成后所有勾选的构件ID(显示控制tree)
				prevCheckedVisibleKeys:null,	//上次勾选后的 构件ID列表（显示控制tree）
				//checkedVisibleKeys:[],			//当前选中的显示列表（显示tree）
				keepAlive:false,
			}
		},
		components:{
			'el-input':Input,
			'el-tabs':Tabs,
			'el-tab-pane':TabPane,
		},
		methods:{
			//请求模型 tree数据
			getTree(){
				var _this = this;
				this.axios.get(`${this.dataApi}/tree`).then(function(res){
					console.log(res.data,65)
					var data = res.data;
					var arr1 = [];console.time('for-tree')
					for(var key in data){	//key:电气工程:{};土建工程:{}
						arr1.push({
							Name:key,
							Children:[]
						})
						for(var k1 in data[key]){	//k1:电气一次:{},电缆及附件:{},建筑及结构:{}…
							arr1.forEach(function(item,index){
								if(item['Name'] === key){
									item['Children'].push({
										Name:k1,
										Children:[]
									})
								}								
							});
							for(var k2 in data[key][k1]){	//一次设备:{},动力照明:{},户外支架:{}…
								arr1.forEach(function(item,index){
									item["Children"].forEach(function(item1,index2){
										if(item1['Name'] === k1 ){
											item1['Children'].push({
												Name:k2,
												Children:[]
											})
										}
									})
								});
								for(var i = 0;i<data[key][k1][k2].length;i++){
									arr1.forEach(function(j,index){
										j["Children"].forEach(function(j1,index1){
											j1['Children'].forEach(function(j2){
												if(j1['Name'] === k1 ){
												//item1['Name']:'电气一次','电气二次','暖通空调'	
													if(j2["Name"] === k2){
													//item2["Name"]:'动力照明','一次设备','设备列表'	
														j2['Children'].push({
															Name:data[key][k1][k2][i][1],
															Id:data[key][k1][k2][i][0]
														})	
													}
												}
											});
										});
									});			
								};						
							}
						}
					};
					var tree = [{
						Name:'工程项目',
						Id:'project',
						Children:[]
					}];
					arr1.forEach(function(item){
						tree[0]['Children'].push(item);
					});


			
			//超出500条数据进行分组显示
			var tree1 = JSON.parse( JSON.stringify(tree) );				//console.log(tree1)

			tree1.forEach(function(key){										//项目工程		
				key['Children'].forEach(function(key1,index1){					//土建，电气
					key1['Children'].forEach(function(key2,index2){			//一次，二次，建筑及解构,通用
						key2['Children'].forEach(function(key3,index3){		//照明，一次设备，构筑物，户外支架		(三级名称)	
							if(key3['Children'].length > 1000){
//console.log(tree1[0]['Children'][index1]['Children'][index2]['Children'][index3],)	//{name: "户外支架", Children: Array(4)}
//console.log(138,key3['Name']);				//户外支架								
								//超限数据
								var thirdData = JSON.parse(		JSON.stringify( tree1[0]['Children'][index1]['Children'][index2]['Children'][index3]['Children'] )	);
								//name3
								var name3 = key3['Name'];
								if(name3 == '' && key2['Name'] == '通用'){
									name3 = '相关设备列表'
								}
								_this.formatTreeData(tree1,index1,index2,index3,name3,thirdData)
							}
						})
					})
				})
			});	console.timeEnd('for-tree');				
					/*//将通用设备分为500 一组
					var tree1 = [],items = [],count = 0;
					tree1 = JSON.parse(JSON.stringify(tree));
					items = JSON.parse(JSON.stringify(tree1[0]['Children'][0]['Children'][3]['Children'][0]['Children']));
					tree1[0]['Children'][0]['Children'][3]['Children'] = [];		
					count = Math.ceil(items.length / 500);						//console.log(tree1,items,count,137)
					for(var i = 1;i<= count;i ++){
						tree1[0]['Children'][0]['Children'][3]['Children'].push({
							Name:'相关设备列表' +i,
							Children:[]
						})
					};			
					tree1[0]['Children'][0]['Children'][3]['Children'].forEach(function(item,index){	
						item['Children'] = items.slice( 500*(index + 1 -1),500*(index + 1) );
					});*/					
					_this.visibleTreeData = tree1;	
					_this.treeData = tree1;		//console.log(Date.now())

					_this.$nextTick(() => {
						_this.defaultCheckedKeys = _this.$refs.treeVisible.getCheckedKeys().filter(function(item){
							return item != undefined && item != 'project';
						});								console.log(_this.defaultCheckedKeys.length,Date.now())
						_this.$bus.$emit('visibleChecked',_this.defaultCheckedKeys);
						// console.log(Date.now(),'_this.defaultCheckedKeys',_this.defaultCheckedKeys)
					});

					/*setTimeout(function(){
						_this.defaultCheckedKeys = _this.$refs.treeVisible.getCheckedKeys();//console.log(new Date().format(),'_this.defaultCheckedKeys')
					},1500)*/
				}).catch(function(e){
					console.log(e)
				})
			},

			//格式化处理tree数据
			formatTreeData(tree1,index1,index2,index3,name3,thirdData){
				var count = 0;
				count = Math.ceil(thirdData.length / 1000);										//console.log(count,name3)
				tree1[0]['Children'][index1]['Children'][index2]['Children'].splice(index3,1);	//console.log()			
				for(var i = 1;i<= count;i ++){					
					tree1[0]['Children'][index1]['Children'][index2]['Children'].push({
						Name: name3 +i,
						Children:[]
					})
				};																					//console.log(tree1[0]['Children'][index1]['Children'][index2]['Children'])
				tree1[0]['Children'][index1]['Children'][index2]['Children'].forEach(function(item,index){	
					if(item['Name'].indexOf(name3) > -1){	
						var num = item['Name'].slice(-1);			
						if ((item['Name'].length - name3.length) == 2 ){
							num = item['Name'].slice(-2);
						};						
																		//console.log(item,num)
																		//console.log(thirdData,thirdData.slice( 800*(num  -1),800*num ),num,count)
						item['Children'] = thirdData.slice( 1000*(num  -1),1000*num );
					}					
				});
			},
			//获取管理参数数据			
			getManage(treeId){
				var _this = this;
				this.axios.get(`${this.dataApi}/manage/${treeId}`).then(function(res){
					console.log(res);
					var data = res.data;					
					_this.$bus.$emit('sendManageData',data);
				}).catch(function(e){
					console.log(e)
				});
			},
			//获取设计参数数据
			getDesign(treeId){
				var _this = this;
				this.axios.get(`${this.dataApi}/design/${treeId}`).then(function(res){
					console.log(res);
					var data = res.data;					
					_this.$bus.$emit('sendDesignData',data);
				}).catch(function(e){
					console.log(e)
				});
			},
			//axios 请求量测数据(遥测、遥信)
			getYcYx(treeId){
				var _this = this;
				let ycdata = [];
				// let yxdata = [];				
	  			this.axios.get(`${this.dataApi}/yc/${treeId}`).then(function(res){console.log(res)
	  				if($.isEmptyObject(res.data) || res.data == ""){
	  					_this.$bus.$emit('measurationIsShow',false);
	  					_this.$bus.$emit('sendYcData',[]);
	  				}else{
	  					var Data = res.data;
	  					Data.forEach(function(item){
	  						ycdata.push({Name:item[0],Value:item[2],system:item[1]});
	  						_this.$bus.$emit('sendYcData',ycdata);
	    						_this.$bus.$emit('measurationIsShow',true);
	  					})
	  				}
	  			}).catch(function(e){
					console.log(e,167,e.message);
					/*_this.$bus.$emit('measurationIsShow',false);
					_this.$bus.$emit('sendYcData',[]);*/
	  			})
			},
			//点击tree上叶节点显示请求数据
			handleNodeClick(data,node,ele) {//console.log($('.el-table'),document.querySelector('.el-table'))
				console.log("node-click",data.Id);			
        				var treeId =    data.Id; 
				//if(treeId !== undefined && treeId.length === 45 && Number(treeId).toString() === "NaN"){//alert(true)
				if(treeId !== undefined && treeId.length === 45 ){//alert(true)
					this.$bus.$emit('rightBarShow',true);					
					this.getManage(treeId)		//axios 请求管理数据
					this.getDesign(treeId)		//axios 请求设计数据
					this.getYcYx(treeId);			//axios 请求量测数据(遥测、遥信)
				}				
    			},    			
    			handleCheckChange(data,checked,indeterminate){
    				// console.log("checkChange",data,checked,indeterminate)      				
    			},
    			handleCurrentChange(data,node){
    				// console.log("currentChange",data,node)
    			}, 
    			handleClick(tab, event) {
			// console.log(tab, event);
			},
    			//tree节点过滤 搜索
    			filterNode(value, data,node) {
	        		if (!value) return true;
	        		return data.Name.indexOf(value) !== -1;
	      	},
	      	//获取2个数组的差值
	      	diff(arr1, arr2) {  				
				var set1 = new Set(arr1);
    				var set2 = new Set(arr2);

	    			var subset = [];	    			
	    			if(set1.size > set2.size){
	    				for (let item of set1) {
		        			if (!set2.has(item)) {
		            			subset.push(item);
		        			}
		    			};
	    			}else if(set1.size < set2.size){
	    				for (let item of set2) {
		        			if (!set1.has(item)) {
		            			subset.push(item);
		        			}
		    			};
	    			}
	    			return subset;							
			},
			//勾选高亮显示
    			handleCheck(data,node){								//console.log("复选框被点击check事件",data,node,data.Children)
    				console.time('highlight');
    				var _this = this;  
    				let bimEngine = this.modelMain.getBimEngine();
    				let highlightManager	= 	bimEngine.getHighlightManager();	 
    				var checkedKeys = this.$refs.tree.getCheckedKeys();	//console.log(checkedKeys)
    				checkedKeys = checkedKeys.filter(function(item){
    					return item != undefined && item != 'project';
    				});														//console.log(checkedKeys,'prevCheckedKeys.length = '+this.prevCheckedKeys.length)
    				// console.timeEnd('checkedKeys')
    				
    				//点击后选中为0， 则清除上次选中高亮
    				if(checkedKeys.length == 0){						//console.log('清除高亮')
    					highlightManager.clearHighlightElementList();    					
    				}else{	//点击后有选中
    					//没有上次选中数据则判断为首次选择，设置当前选择数据高亮
    					if(this.prevCheckedKeys.length == 0){			//console.log('首次选择')
    						highlightManager.highlightElementList(checkedKeys);
    						
    					//点击前有选中节点，判断这次是添加还是减少
    					}else{												//console.log(this.diff(this.prevCheckedKeys,checkedKeys))
    						//获取当前选择和上次选择的差值
    						var diffCheckedKeys = this.diff(this.prevCheckedKeys,checkedKeys);    						
  						//减少
    						if(this.prevCheckedKeys.length > checkedKeys.length){			//console.log('减少高亮')
    							highlightManager.unHighlightElementList(diffCheckedKeys);
    						//添加
    						}else if(this.prevCheckedKeys.length < checkedKeys.length){	//console.log('添加高亮')
    																									//console.time('highlight-1000')
    							highlightManager.highlightElementList(diffCheckedKeys);			//console.timeEnd('highlight-1000')
    						};    						
    					};
    				};
    				//保存当前选择数据
    				this.prevCheckedKeys = checkedKeys;
    				bimEngine = null;
    				highlightManager = null;
    				console.timeEnd('highlight');    				
    			},
			//勾选显示控制
		      treeVisible(){		console.time('treeVisible');
		      	var _this = this;
		      	let bimEngine = this.modelMain.getBimEngine();
		      	
		      	//点击后保持勾选的节点
		      	var checkedKeys = this.$refs.treeVisible.getCheckedKeys();	//console.log(checkedKeys)
    				checkedKeys = checkedKeys.filter(function(item){
    					return item != undefined && item != 'project';
    				});
    				
    				this.$bus.$emit('visibleChecked',checkedKeys);
    				//console.log(checkedKeys,);
    				//点击后没有选中节点，隐藏节点
    				if(checkedKeys.length == 0){						
    					//首次操作，隐藏所有节点(10 ==> 0)
    					if(this.prevCheckedVisibleKeys == null ){			console.log('隐藏所有')
    						bimEngine.setElementListVisible(this.defaultCheckedKeys,false);
    					//非首次操作，隐藏上次选中的节点(6==>10,10==>0 || 5 ==> 0)
    					}else{													console.log('隐藏上次所有')
    						bimEngine.setElementListVisible(this.prevCheckedVisibleKeys,false);
    					}; 
    				//点击后有选中节点   					
    				}else{
    					//上次没有选中节点，隐藏勾选节点(10 ==> 1)
    					if(this.prevCheckedVisibleKeys == null){										console.time('diff');			
    						let diffHiddenKeys = this.diff(this.defaultCheckedKeys,checkedKeys);	console.timeEnd('diff');//console.log(diffHiddenKeys)
    																										console.log('隐藏选中')
    						bimEngine.setElementListVisible(diffHiddenKeys,false);
    					
    					//从0到多，显示勾选(0 ==> 8 || 10)
    					}else if(this.prevCheckedVisibleKeys.length == 0  ){				console.log('显示勾选')
    						bimEngine.setElementListVisible(checkedKeys,true);

    					//上次有选中节点，点击后仍有选中（6 ==>8 || 6 ==> 5）
    					}else{						//console.log(this.diff(this.prevCheckedVisibleKeys,checkedKeys))
    						//获取当前选择和上次选择的差值
    																												console.time('diff');
    						var diffCheckedKeys = this.diff(this.prevCheckedVisibleKeys,checkedKeys); 	console.timeEnd('diff');
    						//上次数据少于本次选中数据，显示差值
    						if(this.prevCheckedVisibleKeys.length < checkedKeys.length){	console.log('显示');	//console.time('visible-1000')
    							bimEngine.setElementListVisible(diffCheckedKeys,true);								//console.timeEnd('visible-1000')
    						//上次数据多于本次选中数据，隐藏差值
    						}else if(this.prevCheckedVisibleKeys.length > checkedKeys.length){		console.log('隐藏')
    							bimEngine.setElementListVisible(diffCheckedKeys,false);    							
    						}
    					}
    				};
    				this.prevCheckedVisibleKeys = checkedKeys;
    				bimEngine = null;
    				console.timeEnd('treeVisible');	
    				console.log('%c <------------------------------------>','color:pink')	      	
		    	}    			
		},
		mounted:function(){window.tree = this.$refs.tree;
			var _this = this;
			//将tree数据this.$refs.tree传递给home.vue			
			this.$emit('treeRefs',this.$refs.tree);

			//点击画布模型选中构件后 通过axios请求渲染模型数据
			this.$bus.$on('selectElementID',function(globalId){	
				console.log(globalId,new Date().getTime(),342);
				_this.getManage(globalId)		//axios 请求管理数据
				_this.getDesign(globalId)		//axios 请求设计数据
				_this.getYcYx(globalId);		//axios 请求遥测、遥信数据
			});
			this.$bus.$on('clearTreeChecked',function(data){
				// _this.$refs.tree.setCheckedKeys([]);
			});
			this.getTree();
			setTimeout(function(){
				_this.keepalive = true;
			},2000);	
		},
		activated: function () {		
			if(this.keepalive){
				var _this = this;
				this.defaultCheckedKeys = this.$refs.treeVisible.getCheckedKeys().filter(function(item){
					return item != undefined && item != 'project';
				});							console.log('tree activated',this.defaultCheckedKeys.length,Date.now())
				this.$bus.$emit('visibleChecked',_this.defaultCheckedKeys);
			}
		},
		beforeDestroy(){
			// this.modelMain = null;
			this.$bus.$off('selectElementID');
		},
		watch:{
			checkedId:function(newValue,oldValue){
				// console.log(newValue,oldValue)
				if(newValue.length === 0){//console.log("清除")
					this.$bus.$emit('rightBarShow',false);
					this.$bus.$emit('sendManageData',[]);
					this.$bus.$emit('sendDesignData',[]);
					this.$bus.$emit('sendYcData',[]);
	    				// this.$bus.$emit('sendYxData',[]);
				}
			},
			filterText(val) {
		        	this.$refs.tree.filter(val);
		     }
		}
	}
</script>
<style scoped>
	#sidebar{
		/* box-sizing: border-box; */
		width:calc(20% - 30px);
		height:800px;
		padding: 0 10px;
		margin:0 5px;
		float:left;
		background-color: #fff;		
	}
	.tree{
		width: calc(100% - 4px);
		height: 740px;
		overflow-x: scroll;
		overflow-y: auto;		
		border: 2px solid #cbcbcb;
	}		
</style>
<style>
	.el-tree-node__content:hover{
		background-color: #d9e7fb;
	}
	.el-tree>.el-tree-node{
		min-width: 100%;
		display: inline-block !important;
	}
</style>