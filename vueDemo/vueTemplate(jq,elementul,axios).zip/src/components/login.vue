<template>
	<div id="login">
		<div id="head" class="clearfix">
			<div class="logo left"><img src="../assets/page_logo.png" alt=""></div>
			<div class="right welcome">欢迎登录</div>
		</div>			
		<div class="login">			
			<el-form :model="ruleForm" status-icon :rules="rules" ref="ruleForm" label-width="80px" class="demo-ruleForm">
				<el-form-item label="账号" prop="userName">
			    		<el-input type="text" v-model="ruleForm.userName" auto-complete="off" placeholder="请输入账号">
			    			<!-- <i slot="prefix" class="el-input__icon el-icon-search"></i> -->
			    		</el-input>
			  	</el-form-item>
			  	<el-form-item label="密码" prop="passWord" >
			    		<el-input type="password" v-model="ruleForm.passWord" auto-complete="off" placeholder="请输入密码" @keyup.enter.native="submitForm('ruleForm')">
			    			<!-- <img src="../assets/username.png" alt="" slot="prefix" class="el-input__icon " style="width:20px;height:auto"> -->
			    		</el-input>
			  	</el-form-item>			  
			 
			  	<el-form-item  class="edit" style=""> 
			    		<el-button type="primary" @click="submitForm('ruleForm')" :disabled='disabled'>登录</el-button>
			    		<!-- <el-button @click="resetForm('ruleForm')">重置</el-button> -->
			  	</el-form-item>
			</el-form>
		</div>
		<foot></foot>
	</div>
</template>
<script>
	import Vue from 'vue'
	import Foot from './Foot.vue'
	import {Form,FormItem,Input,Button,Icon} from 'element-ui'
	Vue.use(Form,FormItem,Input,Button,Icon)
	export default{
		name:'login',
		data(){
			var validateName = (rule,value,callback)=> {
				if(value === ''){
					callback(new Error('请输入账号'));
				};
				callback();
			};
		 	var validatePass = (rule, value, callback) => {
        				if (value === '') {
          					callback(new Error('请输入密码'));
        				} else {
          					// if (this.ruleForm.checkPass !== '') {
            			// 		this.$refs.ruleForm.validateField('checkPass');
          					// }
          					callback();
        				}
      			};
			return {
				disabled:false,
				ruleForm:{
					userName:'',
					passWord:'',
				},
				rules:{
					userName:{ required: true,validator: validateName, trigger: 'blur'},
					passWord:{ required: true,validator: validatePass, trigger: 'blur'},
				}
			}
		},
		components:{
			'el-form':Form,
			'el-form-item':FormItem,
			'el-input':Input,
			'el-button':Button,
			Foot
		},
		methods:{
			submitForm(formName) {
				var _this = this;
        				this.$refs[formName].validate((valid) => {
          				if (valid) { 
        					_this.disabled = true;
        					_this.cookie.clear();           					
          					_this.axios.post(`${this.dataApi}/login`,{
	      					userName:_this.ruleForm['userName'],
	      					passWord:_this.ruleForm['passWord']
	      				}).then(function(res){
	      					console.log(res)
	      					var data = res.data;
	      					if(data == 0){			//普通用户
	      						_this.cookie.set('userName',_this.ruleForm['userName']);
	      						_this.cookie.set('superUser',false);
	      						_this.$router.push({								    	
							    		name: 'home',
								    	params: {								        		
							        		userName:_this.ruleForm['userName'],
							        		superUser:false
								    	}
							    });
	      					}else if(data == 1){	//超级用户
	      						_this.cookie.set('userName',_this.ruleForm['userName']);
	      						_this.cookie.set('superUser',true);
	      						_this.$router.push({								    	
							    		name: 'home',
							    		params: {								        		
							        		userName:_this.ruleForm['userName'],
							        		superUser:true
							    		}
								});	
	      					}else if(data == -1){	//密码错误
	      						_this.MessageBox.alert('密码错误，请重新登录', '提示', {
									confirmButtonText: '确定',
									callback: action => {
							          			_this.disabled = false;
							          		},
									center:true
								});
	      					}else if(data == -2){	//账户不存在
	      						_this.MessageBox.alert('账户不存在，请重新登录', '提示', {
									confirmButtonText: '确定',
									callback: action => {
							          			_this.disabled = false;
							          		},
									center:true
								});
	      					};		      						      					
	      				}).catch(function(err){
	      					console.log(err);
	      					_this.MessageBox.alert('请求失败，请检查网络', '提示', {
								confirmButtonText: '确定',
								callback: action => {
						          			_this.disabled = false;
						          		},
								center:true
							});
		      			});
          				} else {
            				console.log('error submit!!');
            					return false;
          					}
        				});
      		},
      		resetForm(formName) {
        			this.$refs[formName].resetFields();
      		},
      		//如果cookie保存有登录 则跳转到主页
      		getLoginUserCookie(){
      			var cookieUserName = this.cookie.get("userName");
				if(cookieUserName){
					this.$router.push('/index')			
				};
			},
		},
		mounted:function(){			
			this.getLoginUserCookie();			
		}
	}
</script>
<style scoped>
	#head{
		background-color: #208C7D;
		padding: 0 300px;
		height: 60px;
		line-height: 60px;
	}
	.login{
		width: 400px;
		height: 180px;
		/* margin: 15px auto; */
		padding: 20px;
		border: 1px solid #ebebeb;
    		border-radius: 10px;
    		background: rgba(255,255,255,0.7);
    		position:absolute;
            left:0;
            top: 0;
            bottom: 0;
            right: 0;
            margin: auto;
	}
	#login #footnote{
		position: fixed;
		bottom: 0;
	}
</style>
<style>
	.login button{
		background-color: #208C7D;
	}
	.edit .el-form-item__content{
		margin-left: 0 !important;
	}
</style>