<template>
	<el-dialog class="editPsd" center  title="修改密码" :visible.sync="dialogVisible" width="40%"  :before-close="handleClose" style='border-radius: 10px;'> 
		  
		<el-form :model="ruleForm" status-icon :rules="rules" ref="ruleForm" label-width="80px" class="demo-ruleForm">
			<el-form-item label="旧密码" prop="oldPass">
				<el-input type="password" v-model="ruleForm.oldPass" auto-complete="off"></el-input>
			</el-form-item>
			<el-form-item label="新密码" prop="pass">
				<el-input type="password" v-model="ruleForm.pass" auto-complete="off"></el-input>
			</el-form-item>
			<el-form-item label="确认新密码" prop="checkPass">
				<el-input type="password" v-model="ruleForm.checkPass" auto-complete="off" @keyup.enter.native="submitForm('ruleForm')"></el-input>
			</el-form-item> 
		</el-form>  
	  	<span slot="footer" class="dialog-footer">		    				    		
	    		<el-button type="primary" @click="submitForm('ruleForm')">修改</el-button>
	    		<el-button @click="closeDialog()">取 消</el-button>
	  	</span>
	</el-dialog>	
</template>
<script>
	import Vue from 'vue'
	import {Dialog,Form,FormItem,Input,Button} from 'element-ui'
	Vue.use(Dialog,Form,FormItem,Input,Button)
	export default{
		name:'editPsd',
		props:['dialogVisible',"editName",'loginName'],		
		data(){	
			var validateOldPass = (rule, value, callback) => {
	        		if (value === '') {
	          			callback(new Error('请输入旧密码'));
	        		} else {	          			
	          			callback();
	        		}	
	      	};
			var validatePass = (rule, value, callback) => {
	        		if (value === '') {
	          			callback(new Error('请输入新密码'));
	        		} else {
	          			if (this.ruleForm.checkPass !== '') {
	            			this.$refs.ruleForm.validateField('checkPass');
	          			}
	          			callback();
	        		}	
	      	};
	      	var validatePass2 = (rule, value, callback) => {
	        		if (value === '') {
	          			callback(new Error('请再次输入密码'));
	        		} else if (value !== this.ruleForm.pass) {
	          			callback(new Error('两次输入密码不一致!'));
	        		} else {
	          			callback();
	        		}
	      	};		
			return {							
				username:'',
				superuser:false,
				// dialogVisible: false,
				ruleForm: {
					oldPass:'',	
    					pass: '',
    					checkPass: '',          
  				},
  				rules: {
  					oldPass: [
        					{ required: true,validator: validateOldPass, trigger: 'blur' }
      				],
    					pass: [
      					{ required: true,validator: validatePass, trigger: 'blur' }
    					],
    					checkPass: [
      					{ required: true,validator: validatePass2, trigger: 'blur' }
    					],          
  				}      		
			}
		},
		components:{			
			'el-dialog':Dialog,
			'el-form':Form,
			'el-form-item':FormItem,
			'el-input':Input,
			'el-button':Button,			
		},
		methods:{
			/*close(){console.log(111)
  				this.$refs['ruleForm'].resetFields();
  				this.$emit('update:dialogVisible', false);
  			},*/
  			closeDialog(){			//console.log(22)
  				this.$refs['ruleForm'].resetFields();
  				this.$emit('update:dialogVisible', false);
  			},
  			handleClose(done){	//console.log(333)
  				this.closeDialog();
  			},
  			submitForm(formName) {	console.log(this.loginName)
  				var _this = this;
    				this.$refs[formName].validate((valid) => {
      				if (valid) {            					
        					_this.axios.post(`${this.dataApi}/updateUser`,{
        						username:_this.editName,
        						oldPassword:_this.ruleForm['oldPass'],
        						newPassword:_this.ruleForm['pass']
        					}).then(function(res){		console.log(res)
        						var data = res.data;
        						//修改成功
        						if(data == 1){
        							if(_this.editName === _this.loginName){
        								_this.MessageBox.alert('修改成功，请重新登录', '提示', {
							          		confirmButtonText: '确定',
							          		callback: action => {
							            		_this.$router.push('/')
							          		},
							          		center:true
							        	});
        							}else{
        								_this.MessageBox.alert('修改成功', '提示', {
							          		confirmButtonText: '确定',
							          		callback: action => {							            		
							            		_this.closeDialog();
							          		},
							          		center:true
							        	});
        							}
        						//修改错误，与原密码一致	
        						}else if(data == -1){
        							_this.MessageBox.alert('密码与原密码重复，请重新设置', '提示', {
						          		confirmButtonText: '确定',
						          		center:true
						        	});
        						}
        					}).catch(function(err){
        						console.log(err)
        					})
      				} else {
        					console.log('error submit!!');
        					_this.MessageBox.alert('密码验证错误', '提示', {
				          		confirmButtonText: '确定',					          		
				          		center:true
				        	});
        					return false;
      				}
    				});
        				// this.dialogVisible = false;
        				// this.$refs['ruleForm'].resetFields();
        				// this.$emit('update:dialogVisible', false)
    			},
    			resetForm(formName) {
      			this.$refs[formName].resetFields();        				
    			}
		},
		mounted(){

		}
	}
</script>
<style scoped>

</style>