<template>
	<div class="wrapper">
		<!-- <home-header :bimviz='newModel' :bimvizLoadCompleted='OnSceneLoadCompleted' @alarmCarousel='carouselData'></home-header> -->
		<home-header  @alarmCarousel='carouselData' @sendFlashData = 'acceptFlashLists'></home-header>
		<div id="alarm" v-if='alarmData.length > 0'>
			<h3 style="text-align: left;line-height: 30px;">报警信息</h3>
			<el-carousel trigger="click"  height='30px' indicator-position="none" >
		      			<el-carousel-item v-for="(item,index) in alarmData" :key="index" >      				
			<p style="line-height: 30px;text-align: left;">
				<span style="margin-right:10px;color:red;">告警信息<i class="el-icon-bell"></i>:</span>{{item.Time}};&nbsp;&nbsp;{{item.Device}};&nbsp;&nbsp;{{item.Level}};&nbsp;&nbsp;{{item.Name}};&nbsp;&nbsp;{{item.State === '1'?'动作':'复归'}};&nbsp;&nbsp;{{item.System === '1'?'主控':'辅控'}}
			</p>        					
		      			</el-carousel-item>
		    			</el-carousel>    			
		</div>

		<div class="main clearfix">
			<side-bar  @treeRefs='acceptTreeRefs'  :modelMain ="newModel" ></side-bar>
			<right-bar :bimEngine='newModel'></right-bar>
			<div id="content"></div>
			<div id="messages"></div>
		</div>
		<foot-note ></foot-note>		
	</div>
</template>
<script>
	import Vue from 'vue'
	import {Icon,Carousel,CarouselItem,Table,TableColumn,Button,Loading} from 'element-ui'
	import SideBar from './components/SideBar'
	import RightBar from './components/RightBar'
	import HomeHeader from './components/HomeHeader'
	import FootNote from './components/Foot'	
	Vue.use(Icon,Carousel,CarouselItem,Table,TableColumn,Button,Loading)
	// const Config = require('../static/js/config');
	export default{
		name:"home",		
		data(){
			return {				
				svgId:'',
				userMsg:' ',
				superuser:null,
				treeData:[],		//tree组件数据
				treeRefs:null,		//tree实例对象				
				newModel:null,	//3D引擎实例对象
				alarmData:[],		//报警信息数据			
				bimvizRGBA:{		//bimviz改变构件的RGBA值(0~1)
					warning:[0.90196,0.62529,0.23529,1.0],
					danger:[0.96078,0.42353,0.42353,1.0],
					primary:[0.25098,0.61961,1,1.0]
				},
				OnSceneLoadCompleted:false, 	//3D模型是否加载完成
				loadingInstance:null,				//loading实例
				flashData:null,						//闪亮构件数组[{globalId:'',Level:'',...},{}]
				fromPath:'',
			}
		},
		components:{
			SideBar,
			RightBar,
			HomeHeader,
			FootNote,	
			'el-carousel':Carousel,
			'el-carousel-item':CarouselItem,
			'el-table':Table,
			'el-table-column':TableColumn,			
		},		
		methods:{	
			//接收列表tree		
			acceptTreeRefs:function(data){
				this.treeRefs = data;
			},
			//接受header组件的轮播数据
	          carouselData(data){	//console.log(new Date().getTime(),101,'carouselData')
	          		this.alarmData = data;
	          		if(data.length > 0){
	          			this.getDevice();
	          		};	          		
	          },
	          //接受homeHeader的当前闪亮数据
		   	acceptFlashLists(data){
		   		this.flashData = data;
		   	},			
			/**/
			//获取警报间隔
			getDevice(){
				let _this = this;
				this.axios.get(`${this.dataApi}/device`).then(function(data){
					//console.log(data)
					var data = data.data,arr = [{value:'All',label:'所有设备'}];
					for(var key in data){						
						arr.push({
							value:key,
							label:data[key]
						});						
					};					
					//console.log(new Date().getTime(),88,'deviceLists')
					arr.forEach(function(item1){
						_this.alarmData.forEach(function(item2){
							if(item2['Device'] === item1['value']){
								item2['Device'] = item1['label']
							};
						})						
					});					
				}).catch(function(err){
					console.log(err)
				})
			},
	         
	          //点击svg接线图后3D引擎对应高亮
	          svgHighLight(bimviz){		console.log(264,new Date())
	          		var _this = this;	
	          		if(this.$route.params.svgId !== undefined){
					this.svgId = this.$route.params.svgId;
					// setTimeout(function(){console.log(_this.svgId)
						bimviz.getHighlightManager().highlightElement(_this.svgId);						
						_this.$bus.$emit('rightBarShow',true);
						_this.$bus.$emit('selectElementID',_this.svgId);	//alert('emit selectElementID')
					// },1*1000);					
				};				
		   	},		   	
			//重置构件颜色并清除计时
	          resetBimviz(list){
	          		var _this = this;
	          		clearInterval(window.timer);
	          		window.timer = null;			//console.log()
	          		list.forEach(function(item){
	          			_this.newModel.getBimEngine().resetElementRGBA(item['globalId']);
	          		});
	          		localStorage.removeItem('flashStr');
				localStorage.removeItem('idStr');
	          		//_this.idLists = [];		          		
	          },
		},
		mounted(){	window.$vm = this;	//console.log('home  mounted',)
			var _this = this;
			$(function(){				
				document.body.scrollTop = document.documentElement.scrollTop = 0;
			});
			
			/*
			*通过prj_ID 创建3D引擎实例化对象
			 */	
			try {
				var prj_ID = config.prj_ID;		//config.js配置	
				// let loadingInstance  = null;
				/*this.loadingInstance = Loading.service({
		    			fullscreen:true,
		    			// target:'.alarm',
		    			text:'模型拼命加载中...',
		    			background:'rgba(0,0,0,.8)'
		    		});*/		
				this.newModel = new modelclass(prj_ID,"content",this.treeRefs,this.$bus);
				this.newModel.init();			console.log(Date.now(),'mounted')
      			//this.$bus.$emit('sendBimviz',this.newModel);
				window.bimEngine = this.newModel.getBimEngine();// console.log(bimEngine)				
				window.bimEngine.addListener(BIMVIZ.EVENT.OnSceneLoadCompleted,function(evt){
					console.log(new Date().format(),'OnSceneLoadCompleted');
					/*_this.$nextTick(() => { // 以服务的方式调用的 Loading 需要异步关闭					
				  		_this.loadingInstance.close();
				  		_this.loadingInstance = null;
					});*/					 				                  			
					_this.svgHighLight(bimEngine);
					_this.OnSceneLoadCompleted = true;	
					_this.$bus.$emit('sendLoadCompleted',true);	
					$('#messages').hide();		
	            	});	
				window.bimEngine.addListener(BIMVIZ.EVENT.OnLoadProgressStep,function (evt){
					console.log(evt.args.current + " " + evt.args.total);
				});
			} catch(e) {		
				/*_this.$nextTick(() => {
					_this.loadingInstance.close();
					_this.loadingInstance = null;
				});*/	
				console.log(e);
			};            
					
		},	
		/*beforeRouteEnter(to,from,next){		console.log(from,to,this)	
			next(vm => {
				if(from.name == 'login'){		console.log('login',Date.now())
					vm.fromPath = 'login';
				}
			})
		},*/			
    		beforeRouteLeave (to, from, next) {			//console.log(+new Date(),window.bimEngine)
    			// 导航离开该组件的对应路由时调用
    			// 可以访问组件实例 `this`
    			/*if(window.bimEngine){
    				window.bimEngine.dispose()
				this.newModel = null;			
				window.bimEngine = null;
				window.$vm = null;
			}*/
			/*跳转离开前清除homeheader计时*/
			//getAlarm()计时
			clearInterval(window.flashTimer);
			window.flashTimer = null;
			//构件闪烁计时
			if(window.timer){
				this.resetBimviz(this.flashData);
			};
			// 时间计时器
			clearInterval(window.nowTime);
			window.nowTime = null;    			
    			next();
  		},	
		beforeDestroy(){						//console.log(+new Date(),window.bimEngine,'beforeDestroy')			
			
		},
		destroyed(){
			console.log(this.newModel,window.bimEngine);	
		},
		activated: function () {			//console.log(Date.now(),'home activated');  
			window.$vm = this;    		
      		this.$bus.$emit('activeIndex','1');
      		this.svgHighLight(bimEngine);
      		//跳转回页面后向homeheader组件传递bimviz和加载状态
      		this.$bus.$emit('sendBimviz',this.newModel);		
      		if(this.OnSceneLoadCompleted == true){
      			this.$bus.$emit('sendLoadCompleted',true);
      			$('#messages').hide();
      		}
    		},
    		deactivated: function () {			//console.log('bimviz deactivated',this)
      		
      		window.$vm = null;
    		}
	}

</script>
<style>
	canvas{
		width: 100% !important;
		/* height: auto !important; */
	}
	.wrapper{
				
	}
	.wrapper #alarm{
		background-color: #FBFEFF;
		padding: 0 15px;
	}
	.main{
		width:100%;
		position: relative;
		margin-top: 10px;		
	}
	.main #content{		
		width: 80%;	
		height:800px;			
		margin-left: 20%;
		background-color: #5fd05d;
	}	
	.el-icon-refresh{color:#c8c8c8;}
	.el-carousel__arrow{
		width: 28px !important;
		height: 28px !important;
	}
	.el-icon-info{margin-right:6px;}
	#quickBarToolbar{
		display: none;
	}
	.bv_viewbox{
		z-index: 1999 !important;
	}
</style>