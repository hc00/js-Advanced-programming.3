<template>
	<div id="app">
		<el-menu
  :default-active="activeIndex2"
  class="el-menu-demo"
  mode="horizontal"
  @select="handleSelect"
  background-color="#545c64"
  text-color="#fff"
  active-text-color="#ffd04b">
  <el-menu-item index="1">处理中心</el-menu-item>
  <el-submenu index="2">
    <template slot="title">我的工作台</template>
    <el-menu-item index="2-1">选项1</el-menu-item>
    <el-menu-item index="2-2">选项2</el-menu-item>
    <el-menu-item index="2-3">选项3</el-menu-item>
    <el-submenu index="2-4">
      <template slot="title">选项4</template>
      <el-menu-item index="2-4-1">选项1</el-menu-item>
      <el-menu-item index="2-4-2">选项2</el-menu-item>
      <el-menu-item index="2-4-3">选项3</el-menu-item>
    </el-submenu>
  </el-submenu>
  <el-menu-item index="3" disabled>消息中心</el-menu-item>
  <el-menu-item index="4"><a href="https://www.ele.me" target="_blank">订单管理</a></el-menu-item>
</el-menu>
		<img src="./assets/logo.png">
		<router-view/>
	</div>
</template>

<script>
	import Vue from 'vue'
	import {Menu,Submenu,MenuItem,Dialog,Form,FormItem,Input,Button,Dropdown,DropdownMenu,DropdownItem} from 'element-ui'
	Vue.use(Menu,Submenu,MenuItem,Dialog,Form,FormItem,Input,Button,Dropdown,DropdownMenu,DropdownItem)
	export default {
		name: 'App',
		data() {
      		return {
        			activeIndex: '1',
        			activeIndex2: '1'
      		};
    		},    
		components:{
			'el-menu':Menu,
			'el-menu-item':MenuItem,
			'el-submenu':Submenu,
			'el-dialog':Dialog,
			'el-form':Form,
			'el-form-item':FormItem,
			'el-input':Input,
			'el-button':Button,
			'el-dropdown':Dropdown,
			'el-dropdown-menu':DropdownMenu,
			'el-dropdown-item':DropdownItem
		},
		methods: {
      		handleSelect(key, keyPath) {
        			console.log(key, keyPath);
      		}
    		},
	}
</script>

<style>
#app {
	font-family: 'Avenir', Helvetica, Arial, sans-serif;
	-webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;
	text-align: center;
	color: #2c3e50;
	margin-top: 60px;
}
</style>
