/*
*config:外部的js文件配置对象
*config.prj_ip;
*config.prj_port;
*config.prj_key
 */
//类构造函数
//输入参数 项目ID ，div ID
function modelclass (prj_ID,divID,treeRefs,bus){
	//3D引擎
	var m_bimEngine = null;
	//标签显示标记
	var m_bmarkerShow = false;
	//标签管理
	var m_markerManager = null;
	//标签
	var m_marker = null;
	//标签坐标
	var m_markerPoint = null;
	//选中构件ID
	var m_selectElementID = null;
	//divID
	var m_divID = divID;
	//高亮管理器
	var m_highlightMgr = null;
	//标签管理器
	var m_markerManager = null;
	var m_prj_id = prj_ID;

	// var m_prj_ip = "cloud.bimviz.io";
	// var m_prj_port = 10001;
	// var m_prj_key = "bb1c032f-9247-4c45-9f5b-3d436cda0950";
		
	var m_prj_ip = config.prj_ip;			
	var m_prj_port = config.prj_port;
	var m_prj_key = config.prj_key;
	
	

	//释放
	this.release = function(){
		m_bimEngine.dispose();
	}
	
	this.setElementVisible = setElementVisible;
	//设置单个构件可见
	function setElementVisible(Id, vis){
		m_bimEngine.setElementVisible(Id, vis);
	}
	
	this.setAllElementsVisibility = setAllElementsVisibility;
	//设置全体构件可见
	function setAllElementsVisibility(visible) {
        		for (var i = 0, iLen = m_bimEngine.getElementNodeList().length; i < iLen; i++){
            			var element = m_bimEngine.getElementNodeList()[i];
            			m_bimEngine.setElementVisible(element.Id, visible);	
        		}
    	};
	
	//设置楼层构件可见
	this.setLayerVisible = setLayerVisible;
	function setLayerVisible(id, vis){			            
		m_bimEngine.showBuildingStorey(id, vis);
	}
	
	//设置类型构件可见
	this.setTypeVisible = setTypeVisible;
	function setTypeVisible(type, vis){
		m_bimEngine.showType(type, vis);
	};
	
	this.setElementColor = setElementColor;
	//设置构件颜色 rgb为数组[1,1,1,1]
	function setElementColor(Id, rgb){
		m_bimEngine.changeElementRGBA(Id, rgb);
	}
	
	//设置构件高亮
	this.setElementhighlight = setElementhighlight;
	function setElementhighlight(Id, state)	{console.log(Id,333)
		if(state)	{
			m_highlightMgr.highlightElement(Id);
		}else{
            			m_highlightMgr.unHighlightElement(Id);
		};

	}
	

	//标签
	var markerTypes = {};
	markerTypes["text-green"] = {
        		html:'<div id="{0}" style="position:absolute;">\
                	<a class="btn btn-3d el-button el-button--primary " style="font-size:16px;padding:5px 8px;color:#fff;cursor: initial;"><i class="et-trophy el-icon-info"></i>{1}</a>\
            		</div>',
        		text:'文字(green)' 
    	};
	//href="#"
	/*<a class="btn btn-3d el-button el-button--primary"><i class="et-trophy el-icon-info"></i>{1}</a>\*/
	//标签展示
	function showMarker(info){//console.log(info,m_markerPoint,m_bimEngine.toScreenPosition(m_markerPoint))
		if(m_marker){
			m_markerManager.removeHtmlMarker(m_marker.id);
			m_marker = null;
		}

		var lstName = [];
		lstName = info.split(':');		
		var id = new Date().getTime();
		var domId = "div_test_html_marker_" + id;
		
		var showinfo = lstName[0] +  " " + lstName[1];		
		// showinfo = lstName[0];
		showinfo = info;		
			
		var type = "text-green";
		var htmlText = markerTypes[type].html.format(domId, showinfo, "");
			
		m_marker = new BIMVIZ.HtmlMarker(id, "", domId, m_markerPoint, htmlText, 7, Infinity, "", "");
		m_markerManager.addHtmlMarker(m_marker);
		m_marker.show();
		
		m_bmarkerShow = true;
	}
	
	//获取3D引擎
	this.getBimEngine = getBimEngine;
	function getBimEngine(){
		return m_bimEngine;
	}

	//当前选中构件ID
	this.getCurrentElementID = getCurrentElementID;
	function getCurrentElementID(){
		return m_selectElementID;
	}
	/*//清除tree选中状态
	this.clearTreeChecked = clearTreeChecked;
	function clearTreeChecked(tree){
		tree.setCheckedKeys([]);//console.log(tree.getCheckedKeys())	
	}*/	
	
	//初始化    // resizeMode: 'fullpage',
	this.init = function(){		
		var _this = this;
       	m_bimEngine = new BIMVIZ.RenderEngine ({
	         	projectId: m_prj_id,
	          	renderDomId: m_divID,
	          	ip: m_prj_ip,
	          	port: m_prj_port,
	          	key: m_prj_key,
			//resizeMode: 'fullpage',
            	// resourcePath:'../sdk/viz/data/',
          		resourcePath:'../../static',
			logo:false,//无LOGO
			/*quickBar: {
                  	show:false //是否启动右键快捷方式
                }*/				
        	});

		//构件选中事件							  
		m_bimEngine.addListener(BIMVIZ.EVENT.OnPickElement,function (evt) {	console.log("选中",evt)
			//标签坐标
			m_markerPoint = evt.args.point.clone().sub(m_bimEngine.CenterPosition);	
			m_selectElementID = evt.args.elementId;		//console.log(m_selectElementID)
			//构建选中时传递Id渲染模型数据
			bus.$emit('selectElementID',m_selectElementID);
					
        		});
			
		//构件选中属性
		m_bimEngine.addListener(BIMVIZ.EVENT.OnSelectElementPropertyList,function (evt)  {//console.log("选中属性")
			var args = evt.args;
			showMarker(args.Name);
			//构建选中后右边栏显示
			bus.$emit('rightBarShow',true);
        		});
		
		//场景加载完成
		m_bimEngine.addListener(BIMVIZ.EVENT.OnSceneLoadCompleted,function (evt)	{

		});
		//购件加载进度
		m_bimEngine.addListener(BIMVIZ.EVENT.OnLoadProgressStep,function (evt){
			
		});
		// console.log(_this,this)
		//选中构件释放
		m_bimEngine.addListener(BIMVIZ.EVENT.OnElementsUnSelected,function (evt){console.log('释放',m_selectElementID,new Date().format())
			/*清除tree的选择框*/			
			bus.$emit('clearTreeChecked',true);
			//构建释放隐藏右侧模块
			bus.$emit('rightBarShow',false);//console.log(new Date().format())	
			if(m_marker){
				m_markerManager.removeHtmlMarker(m_marker.id);
				m_marker = null;
				m_bmarkerShow = false;
			}
			m_selectElementID = 0;	//console.log(new Date().format())			
		});
	
		m_highlightMgr = m_bimEngine.getHighlightManager();
		m_markerManager = m_bimEngine.getMarkerManager();
		var msgControl = new BIMVIZ.UI.DefaultMessageControl(m_bimEngine, 'messages');
		m_bimEngine.start();
	}
		
}