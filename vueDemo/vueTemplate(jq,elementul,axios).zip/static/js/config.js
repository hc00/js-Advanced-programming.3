﻿const  config = {
	prj_ID:'a71b2fdc-0be1-4769-81a1-03b056be001b',		//项目id	
	prj_ip:'10.1.102.163',											//服务IP
	prj_port:'7005',												//服务端口
	prj_key:'B3056CC9-13DB-4fcc-9FC3-6604D93304F4'	//项目key	


	/*prj_ID:'03448e0a-a278-4333-8195-b12941836394',		//项目id	
	prj_ip:'cloud.bimviz.io',										//服务IP
	prj_port:'10001',												//服务端口
	prj_key:'bb1c032f-9247-4c45-9f5b-3d436cda0950'		//项目key*/
};
// export default config;
module.exports = {		
	hostIp:'10.1.101.125'											//本机IP
};