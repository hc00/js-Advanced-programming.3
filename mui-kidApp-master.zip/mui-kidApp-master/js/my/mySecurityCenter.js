mui.init();
mui.plusReady(function() {
	//找回
	document.getElementById("findAccount").addEventListener("tap", function() {
		openNew("findAccount.html");
	});

});